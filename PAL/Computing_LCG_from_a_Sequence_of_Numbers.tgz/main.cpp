#include <bits/stdc++.h>
using namespace std;

// Precomputed primes
static const int PRIMES_5_503[] = {
    5, 7, 11, 13, 17, 19, 23, 29, 31, 37,
    41, 43, 47, 53, 59, 61, 67, 71, 73, 79,
    83, 89, 97, 101, 103, 107, 109, 113, 127, 131,
    137, 139, 149, 151, 157, 163, 167, 173, 179, 181,
    191, 193, 197, 199, 211, 223, 227, 229, 233, 239,
    241, 251, 257, 263, 269, 271, 277, 281, 283, 293,
    307, 311, 313, 317, 331, 337, 347, 349, 353, 359,
    367, 373, 379, 383, 389, 397, 401, 409, 419, 421,
    431, 433, 439, 443, 449, 457, 461, 463, 467, 479,
    487, 491, 499, 503
};
static const int NUM_PRIMES_5_503 = sizeof(PRIMES_5_503)/sizeof(PRIMES_5_503[0]);

// Inline utilities
static inline long long gcdll(long long a, long long b) {
    while (b != 0) {
        long long r = a % b;
        a = b;
        b = r;
    }
    return a;
}
static inline long long modPos(long long x, long long m){
    __int128 r = ( __int128)x % ( __int128)m;
    if(r<0) r += m;
    return (long long)r;
}
static inline long long extGcdInv(long long a, long long m){
    long long x0=1, x1=0, r0=a, r1=m;
    while(r1 != 0){
        long long q = r0 / r1;
        long long r2 = r0 - q*r1;  r0=r1; r1=r2;
        long long x2 = x0 - q*x1;  x0=x1; x1=x2;
    }
    if(x0<0) x0+=m;
    return x0;
}
static inline pair<long long,long long> crtMerge(long long a1, long long n1, long long a2, long long n2){
    long long g = gcdll(n1,n2);
    if(((a2 - a1) % g)!=0) return {-1,-1};
    long long lcm = (n1/g)*n2;
    long long inv = extGcdInv(n1/g, n2/g);
    __int128 diff = ( __int128)(a2 - a1);
    diff = (diff % (n2/g) + (n2/g)) % (n2/g);
    __int128 k = (diff*inv) % (n2/g);
    __int128 x = ( __int128)a1 + k*(n1);
    x = (x % lcm + lcm) % lcm;
    return {(long long)x, lcm};
}

// Filter primes
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long Pmax, Mmax;
    int N;
    cin >> Pmax >> Mmax >> N;
    static long long X[40], D[40];
    for(int i=0; i<N; i++){
        cin >> X[i];
    }
    for(int i=0; i<N-1; i++){
        D[i] = X[i+1] - X[i];
    }
    static long long candidate[100];
    int ccount = 0;
    for(int iP=0; iP<NUM_PRIMES_5_503; iP++){
        long long p = PRIMES_5_503[iP];
        if(p > Pmax) break;
        long long r0 = (D[0] % p + p) % p;
        if(r0==0) continue;
        bool ok=true;
        int i=1;
        for(; i+3<(N-1); i+=4){
            long long r1 = (D[i]   % p + p)%p;
            long long r2 = (D[i+1] % p + p)%p;
            long long r3 = (D[i+2] % p + p)%p;
            long long r4 = (D[i+3] % p + p)%p;
            if(r1!=r0 || r2!=r0 || r3!=r0 || r4!=r0) {
                ok=false;
                break;
            }
        }
        for(; i<(N-1) && ok; i++){
            long long rr = (D[i] % p + p)%p;
            if(rr!=r0) {ok=false; break;}
        }
        if(ok) candidate[ccount++] = p;
    }

// Solve each prime
    long long A_all=0, C_all=0, M_all=1;
    auto checkSequence = [&](long long A, long long C, long long M){
        for(int i=0; i<N-1; i++){
            __int128 nxt = ( __int128)A * X[i] + C;
            if((long long)(nxt % M) != (X[i+1] % M)) {
                return false;
            }
        }
        return true;
    };
    auto solveLCGmodP2 = [&](long long p){
        long long pp = p*p;
        static long long Xmod[40];
        for(int i=0; i<N; i++){
            Xmod[i] = modPos(X[i], pp);
        }
        for(int i=0; i+2<N; i++){
            long long diff = (Xmod[i+1] - Xmod[i]);
            long long g = gcdll((diff<0)?-diff:diff, pp);
            if(g==1){
                long long invd = extGcdInv(modPos(diff, pp), pp);
                long long right = (Xmod[i+2] - Xmod[i+1]);
                long long Araw = modPos((__int128)right * invd, pp);
                if((Araw % p)!=1) continue;
                long long Craw = modPos(Xmod[i+1] - (__int128)Araw*Xmod[i], pp);
                if((Craw % p)==0) continue;
                for(int j=0; j<N-1; j++){
                    __int128 nxt = ( __int128)Araw*Xmod[j] + Craw;
                    if((long long)(nxt % pp) != Xmod[j+1]){
                        goto fail;
                    }
                }
                return make_pair(Araw, Craw);
                fail:;
            }
        }
        return make_pair(-1LL, -1LL);
    };

// Final assembly
    for(int i=0; i<ccount; i++){
        long long p = candidate[i];
        auto [A_p2, C_p2] = solveLCGmodP2(p);
        if(A_p2<0) continue;
        __int128 newM = ( __int128)M_all * ( __int128)(p*p);
        if(newM > Mmax) continue;
        if(gcdll(M_all, p*p)!=1) continue;
        auto mergedA = crtMerge(A_all, M_all, A_p2, p*p);
        if(mergedA.first<0) continue;
        auto mergedC = crtMerge(C_all, M_all, C_p2, p*p);
        if(mergedC.first<0) continue;
        A_all = mergedA.first;
        C_all = mergedC.first;
        M_all = mergedA.second;
    }
    A_all = modPos(A_all, M_all);
    C_all = modPos(C_all, M_all);
    if(A_all==0) A_all += M_all;
    if(C_all==0) C_all += M_all;
    if(A_all>=M_all) A_all%=M_all;
    if(C_all>=M_all) C_all%=M_all;
    if(A_all<1) A_all+=M_all;
    if(C_all<1) C_all+=M_all;
    if(gcdll(C_all, M_all)!=1){}
    if(!checkSequence(A_all, C_all, M_all)){}

// Output
    cout << A_all << " " << C_all << " " << M_all << "\n";
    return 0;
}
