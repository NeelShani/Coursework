#include <bits/stdc++.h>
using namespace std;

struct Transition {
    vector<int> nextWords;
};

int NA, N, E;
vector<string> D;
vector<Transition> transitions;
string T;

static vector<int> matchWordWithEdits(const string &W, const string &T, int startPos, int E) {

    int wlen = (int)W.size();
    int tlen = (int)T.size();

    struct State {
        int wIndex;
        int iIndex;
        int edits;
    };
    auto hashState = [&](const State &s) {
        return ((s.wIndex * 100003 + s.iIndex)*31 + s.edits);
    };
    auto eqState = [&](const State &a, const State &b) {
        return a.wIndex == b.wIndex && a.iIndex == b.iIndex && a.edits == b.edits;
    };
    struct Hash {
        size_t operator()(const State &s) const {
            return ((s.wIndex * 100003 + s.iIndex)*31 + s.edits);
        }
    };
    struct Eq {
        bool operator()(const State &a, const State &b) const {
            return a.wIndex == b.wIndex && a.iIndex == b.iIndex && a.edits == b.edits;
        }
    };

    queue<State> Q;
    unordered_set<State, Hash, Eq> visited;

    Q.push({0, startPos, E});
    visited.insert({0, startPos, E});

    vector<int> resultEnds;

    while(!Q.empty()) {
        auto [wIndex, iIndex, edits] = Q.front();
        Q.pop();

        if (wIndex == wlen) {
            if (iIndex >= startPos) {
                resultEnds.push_back(iIndex-1);
            }
            if (edits > 0 && iIndex < tlen) {
                State nextS = {wIndex, iIndex+1, edits-1};
                if (!visited.count(nextS)) {
                    visited.insert(nextS);
                    Q.push(nextS);
                }
            }
            continue;
        }

        if (wIndex < wlen && iIndex < tlen && W[wIndex] == T[iIndex]) {
            State nextS = {wIndex+1, iIndex+1, edits};
            if (!visited.count(nextS)) {
                visited.insert(nextS);
                Q.push(nextS);
            }
        }

        if (wIndex < wlen && iIndex < tlen && edits > 0) {
            State nextS = {wIndex+1, iIndex+1, edits-1};
            if (!visited.count(nextS)) {
                visited.insert(nextS);
                Q.push(nextS);
            }
        }

        if (iIndex < tlen && edits > 0) {
            State nextS = {wIndex, iIndex+1, edits-1};
            if (!visited.count(nextS)) {
                visited.insert(nextS);
                Q.push(nextS);
            }
        }

    }

    sort(resultEnds.begin(), resultEnds.end());
    resultEnds.erase(unique(resultEnds.begin(), resultEnds.end()), resultEnds.end());

    return resultEnds;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> NA >> N >> E;
    D.resize(N);
    for (int i=0; i<N; i++) cin >> D[i];

    transitions.resize(N);
    for (int i=0; i<N; i++){
        int idx;
        cin >> idx;
        string line;
        getline(cin, line);
        if (!line.empty() && line[0]==' ') line.erase(line.begin());
        if (!line.empty()) {
            stringstream ss(line);
            int j;
            while(ss >> j) {
                transitions[idx].nextWords.push_back(j);
            }
        }
    }

    cin >> T;
    int lenT = (int)T.size();
    string W0 = D[0];
    int lenW0 = (int)W0.size();

    vector<int> startsW0; // positions where W0 ends
    for (int start=0; start+lenW0<=lenT; start++){
        if (T.compare(start, lenW0, W0)==0){
            startsW0.push_back(start+lenW0-1);
        }
    }

    vector<bool> visited((lenT)*N*2,false);
    auto idx_dp = [&](int pos,int i,int f){
        return pos*(N*2) + i*2 + f;
    };

    queue<array<int,3>> Q;
    for (int pos: startsW0) {
        visited[idx_dp(pos,0,0)] = true;
        Q.push({pos,0,0});
    }

    while(!Q.empty()){
        auto [pos, i, f] = Q.front();
        Q.pop();

        for (int nxt: transitions[i].nextWords) {
            if (pos+1 < lenT) {
                vector<int> ends = matchWordWithEdits(D[nxt], T, pos+1, E);
                for (int ep: ends) {
                    int newF = f;
                    if (i == 0) newF = 1;
                    int idx = idx_dp(ep,nxt,newF);
                    if (!visited[idx]) {
                        if (nxt==0 && newF==0) {
                            visited[idx] = true;
                        } else {
                            visited[idx] = true;
                            Q.push({ep,nxt,newF});
                        }
                    }
                }
            }
        }
    }
    vector<int> results;
    for (int pos=0; pos<lenT; pos++) {
        for (int i=0; i<N; i++) {
            if (visited[idx_dp(pos,i,1)]) {
                results.push_back(pos);
                break;
            }
        }
    }

    sort(results.begin(), results.end());
    results.erase(unique(results.begin(), results.end()), results.end());

    for (int i=0; i<(int)results.size(); i++) {
        cout << results[i] << (i+1== (int)results.size()? '\n':' ');
    }

    return 0;
}
