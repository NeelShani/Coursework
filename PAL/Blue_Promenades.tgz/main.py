#finding sccs
def tarjan_scc(N, graph):
    stack = []
    on_stack = [False]*N
    index = [-1]*N
    lowlink = [0]*N
    current_index = 0
    sccs = []
    
    def strongconnect(v):
        nonlocal current_index
        index[v] = current_index
        lowlink[v] = current_index
        current_index += 1
        stack.append(v)
        on_stack[v] = True

        for w in graph[v]:
            if index[w] == -1:
                strongconnect(w)
                lowlink[v] = min(lowlink[v], lowlink[w])
            elif on_stack[w]:
                lowlink[v] = min(lowlink[v], index[w])

        # If v is ->SCC
        if lowlink[v] == index[v]:
            scc = []
            while True:
                w = stack.pop()
                on_stack[w] = False
                scc.append(w)
                if w == v:
                    break
            sccs.append(scc)

    for i in range(N):
        if index[i] == -1:
            strongconnect(i)

    return sccs


from collections import deque
# BFS to get distance array from start to all nodes in subgraph

def bfs(start, adj, n):
    dist = [10**9]*n
    dist[start] = 0
    q = deque([start])
    while q:
        u = q.popleft()
        for w in adj[u]:
            if dist[w] > dist[u] + 1:
                dist[w] = dist[u] + 1
                q.append(w)
    return dist

def solve():
    N, B, M = map(int, input().split())
    blue_nodes = list(map(int, input().split()))

    graph = [[] for _ in range(N)]
    for _ in range(M):
        a, b = map(int, input().split())
        graph[a].append(b)

    # SCCS finding
    sccs = tarjan_scc(N, graph)
    # Map each nodes to its scc_id
    scc_id = [-1]*N
    for i, comp in enumerate(sccs):
        for v in comp:
            scc_id[v] = i
    scc_count = len(sccs)

    # reverse graph for internal computations
    rev_graph = [[] for _ in range(N)]
    for u in range(N):
        for w in graph[u]:
            rev_graph[w].append(u)

    # Identify blue node of each SCC, exactly one blue node.
    blue_in_scc = [-1]*scc_count
    for bv in blue_nodes:
        blue_in_scc[scc_id[bv]] = bv

    # Step 2: Build condensation graph (DAG of SCCs)
    scc_graph = [[] for _ in range(scc_count)]
    # Also keep track of edges between SCCs
    # We'll need them to compute transitions costs
    edges_between_scc = [[] for _ in range(scc_count)]
    for u in range(N):
        for w in graph[u]:
            if scc_id[u] != scc_id[w]:
                scc_graph[scc_id[u]].append(scc_id[w])
                edges_between_scc[scc_id[u]].append((u, w))

    # Step 3: For each SCC, run BFS from blue node to get dist_from_blue
    # and BFS from blue node on reversed edges to get dist_to_blue.
    # We'll create subgraphs of each SCC for these BFS computations.
    # To avoid huge complexity, we do a single pass BFS on the whole graph restricted to SCC.
    # Actually, we can do the BFS directly on the SCC subgraph.
    #
    # We'll store:
    # dist_from_blue_in_scc[i][v_in_scc] and dist_to_blue_in_scc[i][v_in_scc]
    # But indexing might be tricky. Let's map each node to local index within its SCC.
    #
    # Actually, we don't need full arrays for each SCC. We can store dist_from_blue and dist_to_blue 
    # directly using the global node indices, since we know scc_id[v]. 
    # Just ensure we run BFS restricted to nodes of that SCC.
    #
    # We'll precompute adjacency lists restricted to each SCC:
    # Similarly for reverse.

    # Create adjacency for each SCC
    scc_nodes = sccs
    scc_adj = [[] for _ in range(scc_count)]
    scc_rev_adj = [[] for _ in range(scc_count)]

    # We'll build these by scanning scc again:
    # Actually, we can just filter edges of the original graph for each SCC.
    # But that could be costly with large M. Let's do it smarter:
    # We'll mark scc_id and build adjacency for each SCC in O(N+M).
    # We already have graph and rev_graph. We can do:
    # For each edge u->w, if scc_id[u]==scc_id[w], add to scc_adj[scc_id[u]].

    for i in range(scc_count):
        scc_adj[i] = []
        scc_rev_adj[i] = []

    # We need adjacency at node level inside each SCC, not just scc->scc.
    # We'll store them at global level but only for nodes in that SCC.
    # Actually, we can do BFS directly using a filtered adjacency:
    # We'll create for each SCC a subgraph_of_scc = adjacency list of the SCC nodes.
    # Use a dictionary: node_in_scc -> list_of_neighbors_in_scc

    # For efficiency, let's create two arrays:
    # scc_subgraph[u]: edges inside the scc of u
    # scc_subgraph_rev[u]: reverse edges inside the scc of u
    scc_subgraph = [[] for _ in range(N)]
    scc_subgraph_rev = [[] for _ in range(N)]
    for u in range(N):
        for w in graph[u]:
            if scc_id[u] == scc_id[w]:
                scc_subgraph[u].append(w)
                scc_subgraph_rev[w].append(u)

    # Now compute dist_from_blue and dist_to_blue for each SCC:
    dist_from_blue_all = [10**9]*N
    dist_to_blue_all = [10**9]*N

    for i in range(scc_count):
        b = blue_in_scc[i]
        # BFS from blue node to get dist_from_blue_all:
        from collections import deque
        dist_from = [10**9]*len(sccs[i])
        dist_to = [10**9]*len(sccs[i])

        # Map node -> index in scc
        idx_in_scc = {}
        for pos, node in enumerate(sccs[i]):
            idx_in_scc[node] = pos

        start_idx = idx_in_scc[b]

        # dist_from_blue
        dist_from[start_idx] = 0
        q = deque([b])
        while q:
            u = q.popleft()
            for nxt in scc_subgraph[u]:
                if dist_from[idx_in_scc[nxt]] > dist_from[idx_in_scc[u]] + 1:
                    dist_from[idx_in_scc[nxt]] = dist_from[idx_in_scc[u]] + 1
                    q.append(nxt)

        # dist_to_blue (BFS on reversed edges)
        dist_to[start_idx] = 0
        q = deque([b])
        while q:
            u = q.popleft()
            for prv in scc_subgraph_rev[u]:
                if dist_to[idx_in_scc[prv]] > dist_to[idx_in_scc[u]] + 1:
                    dist_to[idx_in_scc[prv]] = dist_to[idx_in_scc[u]] + 1
                    q.append(prv)

        # Store results
        for node in sccs[i]:
            dist_from_blue_all[node] = dist_from[idx_in_scc[node]]
            dist_to_blue_all[node] = dist_to[idx_in_scc[node]]


    # dp as (blue_count, cost), max by blue_count and min by cost.

    # Prepare topological order of SCC DAG to perform DP.
    in_degree = [0]*scc_count
    for i in range(scc_count):
        for nxt in scc_graph[i]:
            in_degree[nxt] += 1

    from collections import deque
    topo_q = deque([i for i in range(scc_count) if in_degree[i]==0])
    topo_order = []
    while topo_q:
        x = topo_q.popleft()
        topo_order.append(x)
        for nxt in scc_graph[x]:
            in_degree[nxt] -= 1
            if in_degree[nxt] == 0:
                topo_q.append(nxt)

    dp = [(1,0) for _ in range(scc_count)]

    # Relax edges in topological order
    for i in topo_order:
        base_blue, base_cost = dp[i]
        for nxt in set(scc_graph[i]):  
            # Computeing transition cost
            # For all edges connecting i to nxt:
            best_transition_cost = 10**9
            for (u,w) in edges_between_scc[i]:
                if scc_id[w] == nxt:
                    cur_cost = dist_from_blue_all[u] + 1 + dist_to_blue_all[w]
                    if cur_cost < best_transition_cost:
                        best_transition_cost = cur_cost
            
            #new dp
            new_blue = base_blue + 1
            new_cost = base_cost + best_transition_cost
            old_blue, old_cost = dp[nxt]
            if new_blue > old_blue or (new_blue == old_blue and new_cost < old_cost):
                dp[nxt] = (new_blue, new_cost)

    # Find the best dp
    best_blue = 0
    best_cost = 0
    for (cb, cc) in dp:
        if cb > best_blue:
            best_blue = cb
            best_cost = cc
        elif cb == best_blue and cc < best_cost:
            best_cost = cc

    print(best_blue, best_cost)


if __name__ == "__main__":
    solve()
