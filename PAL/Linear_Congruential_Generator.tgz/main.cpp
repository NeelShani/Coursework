#include <bits/stdc++.h>
using namespace std;

// id num has exactly k prifactor
bool Kprifactor(int num, int K) {
    int count = 0;
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) {
            ++count;
            num /= i;
            if (num % i == 0){return false;}
        }
    }
    //itself a prime factor
    if (num > 1) {
        ++count;
    }
    return (count == K);
}

int main() {
    // ios::sync_with_stdio(false);
    // cin.tie(nullptr);

    int A, C, M, K, N;
    cin >> A >> C >> M >> K >> N;

    // full sequence of length M from 0
    vector<int> fullSeq(M);
    fullSeq[0] = 0; //start
    for (int i = 1; i < M; i++) {
        fullSeq[i] = (A * fullSeq[i - 1] + C) % M;
        // cout << fullSeq[i] << endl;
    }

    // challenging values
    vector<int> isChall(M);
    for (int i = 0; i < M; i++) {
        isChall[i] = Kprifactor(fullSeq[i], K) ? 1 : 0;
    }

    // first index i in contains the maximum count of challenging values. first bcz there can b many

    int bestIndex = 0;     // so calledddd best index
    int bestCount = -1;    // k factor found to check max


    for (int i = 0; i < M; i++) {
        int countChall = 0;
        for (int j = 0; j < N; j++) {
            countChall += isChall[(i + j) % M];
        }
        if (countChall > bestCount) {
            bestCount = countChall;
            bestIndex = i;
            for (auto u : isChall)
                if(i==u)bestIndex = i-1; //bczz of 1st example, as the 2(ischall) cant be the index

        }
    }



    cout << fullSeq[bestIndex] << " " << bestCount << "\n";

    return 0;
}