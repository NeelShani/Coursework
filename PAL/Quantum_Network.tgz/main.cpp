#include <bits/stdc++.h>
using namespace std;

// Constants for maximum number of QPUs and log depth
const int MAXQ = 50000 + 5;
const int LOG = 17;

// Disjoint Set Union structure
struct DSU {
    vector<int> parent;
    DSU(int n){
        parent.resize(n+1);
        for(int i=0;i<=n;i++) parent[i]=i;
    }
    int find_set(int x){
        if(parent[x]!=x)
            parent[x] = find_set(parent[x]);
        return parent[x];
    }
    void union_set(int x, int y){
        int fx = find_set(x);
        int fy = find_set(y);
        if(fx != fy)
            parent[fx] = fy;
    }
};

// Structure to represent an edge
struct Edge {
    int u;
    int v;
    int m;
    bool inN1;
};

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);

    int Q, C, D;
    cin >> Q >> C >> D;
    vector<Edge> edges(C);

    // Read all potential direct connections
    for(int i=0;i<C;i++){
        cin >> edges[i].u >> edges[i].v >> edges[i].m;
        edges[i].inN1 = false;
    }

    // Step 1: Construct the first network """MST""" Krusky's algorithm
    DSU dsu1(Q);
    long long M1 = 0;
    vector<vector<int>> adj(Q+1, vector<int>());

    for(int i=0;i<C;i++){
        int u = edges[i].u;
        int v = edges[i].v;
        if(dsu1.find_set(u) != dsu1.find_set(v)){
            dsu1.union_set(u, v);
            edges[i].inN1 = true;
            M1 += edges[i].m;
            adj[u].push_back(v);
            adj[v].push_back(u);
        }
    }

    vector<int> depthQ(Q+1, 0);
    vector<vector<int>> up(LOG, vector<int>(Q+1, 0));

    // BFS to set depths and immediate ancestors
    queue<int> q;
    q.push(1);
    depthQ[1] = 0;
    up[0][1] = 1;
    vector<bool> visited(Q+1, false);
    visited[1] = true;

    while(!q.empty()){
        int u = q.front(); q.pop();
        for(auto &v : adj[u]){
            if(!visited[v]){
                visited[v] = true;
                depthQ[v] = depthQ[u] + 1;
                up[0][v] = u;
                q.push(v);
            }
        }
    }

    //ancestor tables for Binary Lifting
    for(int k=1; k<LOG; k++){
        for(int v=1; v<=Q; v++){
            up[k][v] = up[k-1][ up[k-1][v] ];
        }
    }

    auto get_lca = [&](auto &get_lca_ref, int u, int v) -> int {
        if(depthQ[u] < depthQ[v]) swap(u, v);
        // Lift u up to the depth of v
        for(int k=LOG-1; k>=0; k--){
            if(depthQ[u] - (1<<k) >= depthQ[v]){
                u = up[k][u];
            }
        }
        if(u == v) return u;
        // Lift both u and v until their ancestors match
        for(int k=LOG-1; k>=0; k--){
            if(up[k][u] != up[k][v]){
                u = up[k][u];
                v = up[k][v];
            }
        }
        return up[0][u];
    };

    // allowed edges for the second network
    vector<Edge> allowed_edges;
    for(int i=0;i<C;i++){
        if(!edges[i].inN1){
            int u = edges[i].u;
            int v = edges[i].v;
            int lca = get_lca(get_lca, u, v);
            int dist = depthQ[u] + depthQ[v] - 2 * depthQ[lca];
            if(dist <= D-1){
                allowed_edges.push_back(edges[i]);
            }
        }
    }

    // second network using Krusky's algorithm on allowed edges
    DSU dsu2(Q);
    long long M2 = 0;
    for(auto &e : allowed_edges){
        int u = e.u;
        int v = e.v;
        if(dsu2.find_set(u) != dsu2.find_set(v)){
            dsu2.union_set(u, v);
            M2 += e.m;
        }
    }

    // modulo 2^16
    cout << (M1 % 65536) << " " << (M2 % 65536);
}
