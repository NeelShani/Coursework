#include <iostream>
#include <vector>
#include <unordered_map>
#include <set>
#include <string>
#include <algorithm>
#include <queue>
#include <map>

using namespace std;

class Graph {
private:
    unordered_map<int, vector<int>> adjList;
    unordered_map<int, int> nodeKeys;
    set<set<int>> allCycles;

    void findCycleDFS(int current, int parent, unordered_map<int, bool>& visited,
                      vector<int>& path, set<int>& nodesInCurrentPath) {
        visited[current] = true;
        path.push_back(current);
        nodesInCurrentPath.insert(current);

        for (const int& neighbor : adjList[current]) {
            if (neighbor != parent) {
                if (nodesInCurrentPath.find(neighbor) != nodesInCurrentPath.end()) {
                    set<int> cycleNodes;
                    int cycleStart = -1;
                    for (int i = 0; i < path.size(); i++) {
                        if (path[i] == neighbor) {
                            cycleStart = i;
                            break;
                        }
                    }
                    if (cycleStart != -1) {
                        for (int i = cycleStart; i < path.size(); i++) {
                            cycleNodes.insert(path[i]);
                        }
                        allCycles.insert(cycleNodes);
                    }
                } else if (!visited[neighbor]) {
                    findCycleDFS(neighbor, current, visited, path, nodesInCurrentPath);
                }
            }
        }

        path.pop_back();
        nodesInCurrentPath.erase(current);
    }

    int findRootNode(const set<int>& cycleNodes) {
        for (const int& node : cycleNodes) {
            for (const int& neighbor : adjList[node]) {
                if (cycleNodes.find(neighbor) == cycleNodes.end()) {
                    return node;
                }
            }
        }
        return *cycleNodes.begin();
    }

public:
    void addEdge(int u, int v) {
        adjList[u].push_back(v);
        adjList[v].push_back(u);
        nodeKeys[u] = 1;
        nodeKeys[v] = 1;
    }

    void processGraph() {
        unordered_map<int, bool> visited;
        vector<int> path;
        set<int> nodesInCurrentPath;
        allCycles.clear();

        for (const auto& pair : adjList) {
            visited[pair.first] = false;
        }

        for (const auto& pair : adjList) {
            if (!visited[pair.first]) {
                findCycleDFS(pair.first, -1, visited, path, nodesInCurrentPath);
            }
        }

        for (const auto& cycle : allCycles) {
            int rootNode = findRootNode(cycle);
            int cycleLength = cycle.size();

            for (const int& node : cycle) {
                if (node == rootNode) {
                    nodeKeys[node] = cycleLength;
                } else {
                    nodeKeys[node] = 0;
                }
            }
        }

        auto it = adjList.begin();
        while (it != adjList.end()) {
            if (nodeKeys[it->first] == 0) {
                it = adjList.erase(it);
            } else {
                auto& neighbors = it->second;
                neighbors.erase(
                    remove_if(neighbors.begin(), neighbors.end(),
                        [this](const int& node) { return nodeKeys[node] == 0; }),
                    neighbors.end()
                );
                ++it;
            }
        }
    }

    vector<int> findTreeCenters() {
        unordered_map<int, int> degree;
        queue<int> leaves;
        for (const auto& pair : adjList) {
            degree[pair.first] = pair.second.size();
            if (degree[pair.first] == 1) {
                leaves.push(pair.first);
            }
        }

        int remainingNodes = degree.size();
        while (remainingNodes > 2) {
            int leavesCount = leaves.size();
            remainingNodes -= leavesCount;

            for (int i = 0; i < leavesCount; i++) {
                int leaf = leaves.front();
                leaves.pop();
                degree[leaf]--;

                for (int neighbor : adjList[leaf]) {
                    degree[neighbor]--;
                    if (degree[neighbor] == 1) {
                        leaves.push(neighbor);
                    }
                }
            }
        }

        vector<int> centers;
        while (!leaves.empty()) {
            centers.push_back(leaves.front());
            leaves.pop();
        }
        return centers;
    }

    string generateCertificate() {
        vector<int> centers = findTreeCenters();

        vector<string> certificates;
        for (int center : centers) {
            unordered_map<int, bool> visited;
            certificates.push_back(generateCertificateHelper(center, -1, visited));
        }

        sort(certificates.begin(), certificates.end());

        string finalCertificate;
        for (const string& cert : certificates) {
            finalCertificate += cert;
        }
        return finalCertificate;
    }

private:
    string generateCertificateHelper(int node, int parent, unordered_map<int, bool>& visited) {
        visited[node] = true;
        vector<string> childrenCerts;

        for (int neighbor : adjList[node]) {
            if (neighbor != parent && !visited[neighbor]) {
                childrenCerts.push_back(generateCertificateHelper(neighbor, node, visited));
            }
        }

        sort(childrenCerts.begin(), childrenCerts.end());

        string certificate = "(";
        for (const string& childCert : childrenCerts) {
            certificate += childCert;
        }
        certificate += ")";

        if (nodeKeys[node] > 1) {
            certificate = "(" + to_string(nodeKeys[node]) + ")";
        }

        return certificate;
    }
};

int main() {
    int M, A, B;
    cin >> M >> A >> B;

    vector<string> certificates;
    map<string, int> certificateCount;

    for (int i = 0; i < M; i++) {
        Graph g;
        for (int j = 0; j < B; j++) {
            int u, v;
            cin >> u >> v;
            g.addEdge(u, v);
        }

        g.processGraph();
        string cert = g.generateCertificate();
        certificates.push_back(cert);
        certificateCount[cert]++;
    }

    vector<int> isomorphismGroups;
    for (const auto& pair : certificateCount) {
        isomorphismGroups.push_back(pair.second);
    }

    sort(isomorphismGroups.begin(), isomorphismGroups.end());

    for (int count : isomorphismGroups) {
        cout << count << " ";
    }
    cout << endl;

    return 0;
}
