#include <bits/stdc++.h>
using namespace std;

// Variables for Tarjan's algorithm
int LA, CA, DOCK;
vector<vector<int>> adj; // Original graph
vector<int> disc, low, comp_id;
stack<int> st;
vector<bool> in_stack_flag;
int time_dfs = 0, scc_count = 0;

// Sizes of each SCC
vector<int> scc_size;

// Tarjan's algorithm
void tarjan_scc(int u) {
    disc[u] = low[u] = ++time_dfs;
    st.push(u);
    in_stack_flag[u] = true;

    for(auto &v : adj[u]){
        if(disc[v] == -1){
            tarjan_scc(v);
            low[u] = min(low[u], low[v]);
        }
        else if(in_stack_flag[v]){
            low[u] = min(low[u], disc[v]);
        }
    }

    if(low[u] == disc[u]){
        // Found an SCC
        while(true){
            int w = st.top(); st.pop();
            in_stack_flag[w] = false;
            comp_id[w] = scc_count;
            if(w == u) break;
        }
        scc_count++;
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // Input
    cin >> LA >> CA >> DOCK;
    adj.assign(LA, vector<int>());
    vector<pair<int, int>> edges(CA);
    for(int i=0;i<CA;i++){
        int a, b; cin >> a >> b;
        edges[i] = {a, b};
        adj[a].push_back(b);
    }

    // Initialize for Tarjan
    disc.assign(LA, -1);
    low.assign(LA, 0);
    comp_id.assign(LA, -1);
    in_stack_flag.assign(LA, false);

    // Find SCCs
    for(int i=0;i<LA;i++) {
        if(disc[i] == -1){
            tarjan_scc(i);
        }
    }

    // Initialize SCC sizes
    scc_size.assign(scc_count, 0);
    for(int i=0;i<LA;i++) {
        scc_size[comp_id[i]]++;
    }

    // Build Condensed DAG
    vector<vector<int>> cond_dag(scc_count, vector<int>());
    // To avoid multiple edges between same SCCs, using set or check before adding
    vector<unordered_set<int>> cond_dag_set(scc_count, unordered_set<int>());
    for(auto &[u, v] : edges){
        int cu = comp_id[u];
        int cv = comp_id[v];
        if(cu != cv){
            if(!cond_dag_set[cu].count(cv)){
                cond_dag[cu].push_back(cv);
                cond_dag_set[cu].insert(cv);
            }
        }
    }

    // Identify dock's SCC
    int dock_scc = comp_id[DOCK];

    // Count outgoing edges to dock's SCC for each SCC, count them
    vector<int> out_to_dock(scc_count, 0);
    for(auto &[u, v] : edges){
        int cu = comp_id[u];
        int cv = comp_id[v];
        if(cv == dock_scc && cu != dock_scc){
            out_to_dock[cu]++;
        }
    }

    // Collect candidate SCCs that have at least two outgoing edges to dock's SCC
    vector<int> candidates;
    for(int i=0;i<scc_count;i++) {
        if(i != dock_scc && out_to_dock[i] >= 2){
            candidates.push_back(i);
        }
    }

    // If no candidates, output 0
    if(candidates.empty()){
        cout << "0\n";
        return 0;
    }

    // Topological Sort
    // Kahn's algorithm
    vector<int> indegree(scc_count, 0);
    for(int u=0; u<scc_count; u++) {
        for(auto &v : cond_dag[u]){
            indegree[v]++;
        }
    }

    queue<int> q;
    for(int i=0;i<scc_count;i++) {
        if(indegree[i] == 0){
            q.push(i);
        }
    }

    vector<int> topo_order;
    while(!q.empty()){
        int u = q.front(); q.pop();
        topo_order.push_back(u);
        for(auto &v : cond_dag[u]){
            indegree[v]--;
            if(indegree[v] == 0){
                q.push(v);
            }
        }
    }

    // Check if topological sort includes all nodes
    if(topo_order.size() != scc_count){}



        // Initialize max_path_sum,
    vector<long long> max_path_sum(scc_count, 0);
    // Initialize dock_scc
    max_path_sum[dock_scc] = scc_size[dock_scc];

    // Traverse in reverse topological order
    for(int i=topo_order.size()-1; i>=0; i--){
        int u = topo_order[i];
        if(u == dock_scc){
            continue;
        }
        long long current_max = 0;
        for(auto &v : cond_dag[u]){
            current_max = max(current_max, (long long)max_path_sum[v]);
        }
        if(current_max > 0){
            max_path_sum[u] = scc_size[u] + current_max;
        }
        else{
            max_path_sum[u] = 0;
        }
    }

    long long answer = 0;
    for(auto &u : candidates){
        answer = max(answer, max_path_sum[u]);
    }

    cout << answer << "\n";

    return 0;
}
