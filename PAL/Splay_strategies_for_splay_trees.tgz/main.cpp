#include <bits/stdc++.h>
using namespace std;

struct Node {
    int key;
    Node* left;
    Node* right;
    Node* parent;
    Node(int k) : key(k), left(nullptr), right(nullptr), parent(nullptr) {}
};

int getHeight(Node* root) {
    if (!root) return -1;
    queue<pair<Node*, int>> q;
    q.push({root, 0});
    int maxDepth = 0;
    while (!q.empty()) {
        auto [cur, depth] = q.front();
        q.pop();
        maxDepth = max(maxDepth, depth);
        if (cur->left) q.push({cur->left, depth + 1});
        if (cur->right) q.push({cur->right, depth + 1});
    }
    return maxDepth;
}

class SplayTree {
public:
    Node* root;
    bool useOnlyZig;
    SplayTree(bool onlyZig = false) : root(nullptr), useOnlyZig(onlyZig) {}

    void insert(int key) {
        if (!root) {
            root = new Node(key);
            return;
        }
        Node* cur = root;
        Node* par = nullptr;
        while (cur) {
            par = cur;
            if (key < cur->key) cur = cur->left; else cur = cur->right;
        }
        Node* newNode = new Node(key);
        newNode->parent = par;
        if (key < par->key) par->left = newNode; else par->right = newNode;
        splay(newNode);
    }

    void remove(int key) {
        Node* nodeToDelete = searchNode(key);
        if (!nodeToDelete) {
            return;
        }
        splay(nodeToDelete);
        Node* leftSubtree = root->left;
        Node* rightSubtree = root->right;
        if (leftSubtree) leftSubtree->parent = nullptr;
        if (rightSubtree) rightSubtree->parent = nullptr;
        delete root;
        if (!leftSubtree) {
            root = rightSubtree;
        } else {
            Node* maxNode = getMaxNode(leftSubtree);
            splay(maxNode);
            maxNode->right = rightSubtree;
            if (rightSubtree) rightSubtree->parent = maxNode;
            root = maxNode;
        }
    }

    int height() {
        return getHeight(root);
    }

private:
    Node* searchNode(int key) {
        Node* cur = root;
        while (cur) {
            if (key == cur->key) return cur;
            else if (key < cur->key) cur = cur->left;
            else cur = cur->right;
        }
        return nullptr;
    }

    Node* getMaxNode(Node* subtreeRoot) {
        Node* cur = subtreeRoot;
        while (cur->right) cur = cur->right;
        return cur;
    }

    void splay(Node* x) {
        if (!x) return;
        while (x->parent) {
            if (useOnlyZig) {
                doZig(x);
            } else {
                Node* p = x->parent;
                Node* g = p->parent;
                if (!g) {
                    doZig(x);
                } else {
                    bool xIsLeft = (p->left == x);
                    bool pIsLeft = (g->left == p);
                    if (xIsLeft && pIsLeft) {
                        doZig(p);
                        doZig(x);
                    } else if (!xIsLeft && !pIsLeft) {
                        doZig(p);
                        doZig(x);
                    } else {
                        doZig(x);
                        doZig(x);
                    }
                }
            }
        }
        root = x;
    }

    void doZig(Node* x) {
        Node* p = x->parent;
        if (!p) return;
        if (p->left == x) rotateRight(p); else rotateLeft(p);
    }

    void rotateRight(Node* p) {
        Node* x = p->left;
        if (!x) return;
        p->left = x->right;
        if (x->right) x->right->parent = p;
        x->parent = p->parent;
        if (!p->parent) {
            root = x;
        } else if (p->parent->left == p) {
            p->parent->left = x;
        } else {
            p->parent->right = x;
        }
        x->right = p;
        p->parent = x;
    }

    void rotateLeft(Node* p) {
        Node* x = p->right;
        if (!x) return;
        p->right = x->left;
        if (x->left) x->left->parent = p;
        x->parent = p->parent;
        if (!p->parent) {
            root = x;
        } else if (p->parent->left == p) {
            p->parent->left = x;
        } else {
            p->parent->right = x;
        }
        x->left = p;
        p->parent = x;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    SplayTree stStandard(false);
    SplayTree stModified(true);
    for(int i = 0; i < N; i++) {
        int op;
        cin >> op;
        if(op > 0) {
            stStandard.insert(op);
            stModified.insert(op);
        } else {
            int keyToDelete = -op;
            stStandard.remove(keyToDelete);
            stModified.remove(keyToDelete);
        }
    }
    cout << stStandard.height() << " " << stModified.height() << "\n";
    return 0;
}
