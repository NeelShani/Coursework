from abstractagent import AbstractAgent
from blackjack import BlackjackObservation, BlackjackEnv, BlackjackAction
from carddeck import *


class TDAgent(AbstractAgent):
    """
    Implementation of an agent that plays the same strategy as the dealer.
    This means that the agent draws a card when sum of cards in his hand
    is less than 17.

    Your goal is to modify train() method to learn the state utility function
    and the get_hypothesis() method that returns the state utility function.
    I.e. you need to change this agent to a passive reinforcement learning
    agent that learns utility estimates using temporal difference method.
    """
    def __init__(self, env: BlackjackEnv, number_of_episodes: int, alpha: float = 0.05, gamma: float = 1.0):
        super().__init__(env, number_of_episodes)
        self.alpha = alpha  # Learning rate
        self.gamma = gamma  # Discount factor
        self.utility = {} 

    def train(self):
        for i in range(self.number_of_episodes):
            print(i)
            observation, _ = self.env.reset()
            terminal = False
            reward = 0
            current_state = self._get_state_key(observation)
            while not terminal:
                # self.env.render()
                action = self.receive_observation_and_get_action(observation, terminal)
                next_observation, reward, terminal, _, _ = self.env.step(action)
                # TODO your code will be very likely here
                next_state = self._get_state_key(next_observation)

                if current_state not in self.utility:
                    self.utility[current_state] = 0
                if next_state not in self.utility:
                    self.utility[next_state] = 0

                td_target = reward + self.gamma * self.utility[next_state]
                td_error = td_target - self.utility[current_state]
                self.utility[current_state] += self.alpha * td_error

               
                current_state = next_state
                observation = next_observation

            # self.env.render()

    def receive_observation_and_get_action(self, observation: BlackjackObservation, terminal: bool) -> int:
        return BlackjackAction.HIT.value if observation.player_hand.value() < 17 else BlackjackAction.STAND.value

    def get_hypothesis(self, observation: BlackjackObservation, terminal: bool) -> float:
        """
        Implement this method so that I can test your code. This method is supposed to return your learned U value for
        particular observation.

        :param observation: The observation as in the game. Contains information about what the player sees - player's
        hand and dealer's hand.
        :param terminal: Whether the hands were seen after the end of the game, i.e. whether the state is terminal.
        :return: The learned U-value for the given observation.
        """
        state_key = self._get_state_key(observation)
        return self.utility.get(state_key, 0)
    

    def _get_state_key(self, observation: BlackjackObservation) -> tuple:
        player_hand_value = observation.player_hand.value()
        dealer_visible_card = observation.dealer_hand.cards[0].value
        has_ace = int(any(card.value == 11 for card in observation.player_hand.cards))
        return (player_hand_value, dealer_visible_card, has_ace)
