from abstractagent import AbstractAgent
from blackjack import BlackjackEnv, BlackjackObservation, BlackjackAction
from carddeck import *
import random
'''
I couldn't create expected agent. So, I did parameter tuning and try to get best average with the model I created
'''

class SarsaAgent(AbstractAgent):
    """
    Here you will provide your implementation of SARSA method.
    You are supposed to implement train() method. If you want
    to, you can split the code in two phases - training and
    testing, but it is not a requirement.

    For SARSA explanation check AIMA book or Sutton and Burton
    book. You can choose any strategy and/or step-size function
    (learning rate) as long as you fulfil convergence criteria.
    """
    def __init__(
        self,
        env: BlackjackEnv,
        number_of_episodes: int,
        alpha: float = 0.01,
        gamma: float = 0.99,
        epsilon: float = 1.0,
        epsilon_decay: float = 0.99,
    ):
        super().__init__(env, number_of_episodes)
        self.alpha = alpha  # Learning rate
        self.gamma = gamma  # Discount factor
        self.epsilon = epsilon 
        self.epsilon_decay = epsilon_decay  
        self.Q = {}  

    def train(self): 
        for episode in range(self.number_of_episodes):
            observation, _ = self.env.reset()
            terminal = False
            state = self._get_state_key(observation)
            action = self._choose_action(state)
            
            while not terminal:
                next_obs, reward, terminal, _, _ = self.env.step(action)
                next_state = self._get_state_key(next_obs)
                

                next_action = self._choose_action(next_state) if not terminal else None
                
                #sarsa update
                current_q = self.Q.get((state, action), 0.0)
                td_target = reward + (self.gamma * self.Q.get((next_state, next_action), 0.0) if not terminal else 0)
                self.Q[(state, action)] = current_q + self.alpha * (td_target - current_q)
                
                state, action = next_state, next_action
            
            self.epsilon = max(0.01, self.epsilon * self.epsilon_decay)  

    def _choose_action(self, state: tuple) -> int:
        """ε-greedy policy with abstracted states."""
        if random.random() < self.epsilon:
            return random.choice([BlackjackAction.HIT.value, BlackjackAction.STAND.value])
        else:
            q_hit = self.Q.get((state, BlackjackAction.HIT.value), 0.0)
            q_stand = self.Q.get((state, BlackjackAction.STAND.value), 0.0)
            return BlackjackAction.HIT.value if q_hit > q_stand else BlackjackAction.STAND.value

    def _get_state_key(self, observation: BlackjackObservation) -> tuple:
        """State abstraction: Player's hand <15 → 1, else actual value."""
        player_value = observation.player_hand.value()
        abstracted_pv = 1 if player_value < 15 else player_value  # abstraction
        dealer_card = observation.dealer_hand.cards[0].value
        has_ace = int(any(card.value == 11 for card in observation.player_hand.cards))
        return (abstracted_pv, dealer_card, has_ace)
    

    def get_hypothesis(self, observation: BlackjackObservation, terminal: bool, action: int) -> float:
        """
        Implement this method so that I can test your code. This method is supposed to return your learned Q value for
        particular observation and action.

        :param observation: The observation as in the game. Contains information about what the player sees - player's
        hand and dealer's hand.
        :param terminal: Whether the hands were seen after the end of the game, i.e. whether the state is terminal.
        :param action: Action for Q-value.
        :return: The learned Q-value for the given observation and action.
        """
        if terminal: return 0.0
        state = self._get_state_key(observation)
        return self.Q.get((state, action), 0.0)