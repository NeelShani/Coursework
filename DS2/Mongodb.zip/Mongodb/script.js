//const dbName = 'f24_shaninee';

// Creating collections
db.createCollection("users");
db.createCollection("workouts");

//Users
db.users.insertOne({
    username: "john_doe",
    age: 28,
    email: "john.doe@example.com",
    goals: ["Lose weight", "Improve stamina"],
    friends: ["jane_smith", "mike_johnson"],
    stats: { total_sessions: 120, calories_burned: 50000 },
    created_at: new Date("2024-01-15")
});

db.users.insertMany([
    {
        username: "jane_smith",
        age: 25,
        email: "jane.smith@example.com",
        goals: ["Gain muscle"],
        friends: ["john_doe"],
        stats: { total_sessions: 80, calories_burned: 30000 },
        created_at: new Date("2024-02-20")
    },
    {
        username: "mike_johnson",
        age: 32,
        email: "mike.johnson@example.com",
        goals: ["Maintain fitness"],
        friends: ["john_doe", "jane_smith"],
        stats: { total_sessions: 150, calories_burned: 60000 },
        created_at: new Date("2024-03-10")
    },
    {
        username: "alice_brown",
        age: 30,
        email: "alice.brown@example.com",
        goals: ["Run a marathon"],
        friends: ["emma_white"],
        stats: { total_sessions: 200, calories_burned: 70000 },
        created_at: new Date("2024-04-05")
    },
    {
        username: "emma_white",
        age: 27,
        email: "emma.white@example.com",
        goals: ["Lose weight", "Maintain fitness"],
        friends: ["alice_brown"],
        stats: { total_sessions: 90, calories_burned: 35000 },
        created_at: new Date("2024-05-01")
    },
    {
        username: "charlie_black",
        age: 35,
        email: "charlie.black@example.com",
        goals: ["Build endurance"],
        friends: ["david_green"],
        stats: { total_sessions: 50, calories_burned: 15000 },
        created_at: new Date("2024-05-20")
    },
    {
        username: "david_green",
        age: 40,
        email: "david.green@example.com",
        goals: ["Gain muscle", "Improve flexibility"],
        friends: ["charlie_black"],
        stats: { total_sessions: 120, calories_burned: 45000 },
        created_at: new Date("2024-06-10")
    },
    {
        username: "sophia_lee",
        age: 22,
        email: "sophia.lee@example.com",
        goals: ["Stay active"],
        friends: ["oliver_kim"],
        stats: { total_sessions: 60, calories_burned: 25000 },
        created_at: new Date("2024-07-15")
    },
    {
        username: "oliver_kim",
        age: 29,
        email: "oliver.kim@example.com",
        goals: ["Gain muscle", "Improve stamina"],
        friends: ["sophia_lee"],
        stats: { total_sessions: 75, calories_burned: 30000 },
        created_at: new Date("2024-08-10")
    },
    {
        username: "mia_clark",
        age: 24,
        email: "mia.clark@example.com",
        goals: ["Maintain fitness", "Run a marathon"],
        friends: ["john_doe", "jane_smith"],
        stats: { total_sessions: 100, calories_burned: 40000 },
        created_at: new Date("2024-09-01")
    }
]);


//workouts collection
db.workouts.insertOne({
    workout_id: 1,
    user_ref: "john_doe", // Reference to the user
    type: "Cardio",
    exercises: [
        { name: "Running", duration: 30, calories_burned: 300 },
        { name: "Cycling", duration: 45, calories_burned: 400 }
    ],
    date: new Date("2024-09-10")
});
db.workouts.insertMany([
    {
        workout_id: 2,
        user_ref: "jane_smith",
        type: "Strength Training",
        exercises: [
            { name: "Deadlifts", sets: 4, reps: 8, calories_burned: 200 },
            { name: "Squats", sets: 3, reps: 12, calories_burned: 180 }
        ],
        date: new Date("2024-09-11")
    },
    {
        workout_id: 3,
        user_ref: "mike_johnson",
        type: "Cardio",
        exercises: [
            { name: "Swimming", duration: 60, calories_burned: 500 },
            { name: "Rowing", duration: 40, calories_burned: 350 }
        ],
        date: new Date("2024-09-12")
    },
    {
        workout_id: 4,
        user_ref: "alice_brown",
        type: "Endurance",
        exercises: [
            { name: "Hiking", duration: 120, calories_burned: 800 },
            { name: "Jogging", duration: 45, calories_burned: 350 }
        ],
        date: new Date("2024-09-13")
    },
    {
        workout_id: 5,
        user_ref: "emma_white",
        type: "Flexibility",
        exercises: [
            { name: "Yoga", duration: 60, calories_burned: 200 },
            { name: "Stretching", duration: 30, calories_burned: 100 }
        ],
        date: new Date("2024-09-14")
    },
    {
        workout_id: 6,
        user_ref: "charlie_black",
        type: "Strength Training",
        exercises: [
            { name: "Bench Press", sets: 4, reps: 10, calories_burned: 250 },
            { name: "Pull-Ups", sets: 5, reps: 8, calories_burned: 150 }
        ],
        date: new Date("2024-09-15")
    },
    {
        workout_id: 7,
        user_ref: "david_green",
        type: "Cardio",
        exercises: [
            { name: "Running", duration: 30, calories_burned: 300 },
            { name: "Jump Rope", duration: 20, calories_burned: 250 }
        ],
        date: new Date("2024-09-16")
    },
    {
        workout_id: 8,
        user_ref: "sophia_lee",
        type: "Cardio",
        exercises: [
            { name: "Dancing", duration: 60, calories_burned: 400 },
            { name: "Cycling", duration: 40, calories_burned: 350 }
        ],
        date: new Date("2024-09-17")
    },
    {
        workout_id: 9,
        user_ref: "oliver_kim",
        type: "Strength Training",
        exercises: [
            { name: "Push-Ups", sets: 5, reps: 20, calories_burned: 200 },
            { name: "Plank", duration: 5, calories_burned: 50 }
        ],
        date: new Date("2024-09-18")
    },
    {
        workout_id: 10,
        user_ref: "mia_clark",
        type: "Flexibility",
        exercises: [
            { name: "Yoga", duration: 45, calories_burned: 180 },
            { name: "Pilates", duration: 60, calories_burned: 250 }
        ],
        date: new Date("2024-09-19")
    }
]);



db.users.replaceOne(
    { username: "john_doe" },
    {
        username: "john_doe",
        age: 29,
        email: "updated.john.doe@example.com",
        goals: ["Lose weight", "Run a marathon"],
        friends: ["jane_smith"],
        stats: { total_sessions: 130, calories_burned: 55000 },
        created_at: new Date("2024-01-15")
    }
);

db.users.updateOne(
    { username: "jane_smith" },
    { $set: { "stats.calories_burned": 35000 } }
);

db.users.updateMany(
    { "stats.calories_burned": { $lt: 40000 } },
    { $mul: { "stats.total_sessions": 1.1 } } // Increase sessions by 10%
);

// Add
db.users.updateOne(
    { username: "mike_johnson" },
    { $set: { premium_member: true } }
);

// Remove
db.users.updateOne(
    { username: "jane_smith" },
    { $unset: { premium_member: "" } }
);

db.workouts.updateOne(
    { workout_id: 1 },
    { $set: { "exercises.0.duration": 40 } } // Update the first exercise duration
);


// Replace an array element
db.users.updateOne(
    { username: "john_doe" },
    { $set: { "goals.0": "Gain muscle" } }
);

// Add an array element
db.users.updateOne(
    { username: "john_doe" },
    { $push: { goals: "Improve flexibility" } }
);

// Delet an array element
db.users.updateOne(
    { username: "john_doe" },
    { $pull: { goals: "Gain muscle" } }
);

db.users.updateOne(
    { username: "neel_shani" },
    {
        $setOnInsert: {
            username: "neel_shani",
            age: 30,
            email: "neelshani@example.com",
            goals: ["Start a fitness journey"],
            stats: { total_sessions: 0, calories_burned: 0 },
            created_at: new Date()
        }
    },
    { upsert: true }
);

//FIND
//Identifies users who are doing best in the fuild... burned lots of calories or gain muscles
db.users.find(
    {
        $or: [
            { "stats.calories_burned": { $gte: 50000 } },
            { goals: "Gain muscle" }
        ]
    },
    { username: 1, "stats.calories_burned": 1, goals: 1, _id: 0 } 
).sort({ "stats.calories_burned": -1 }).forEach(printjson); // Sort by calories burned (descending)

//Targets users who prefer intense(more duration) cardio workouts, useful for recommending related fitness plans.
db.users.find(
    {
        exercises: { $elemMatch: { type: "Cardio", duration: { $gt: 30 } } }
    },
    { username: 1, exercises: 1, _id: 0 }
).forEach(printjson);


//Tracks new users while excluding unnecessary stats data(comapring dates).
db.users.find(
    { created_at: { $gte: new Date("2024-06-01") } },
    { stats: 0 }
).sort({ created_at: 1 }).forEach(printjson); 

//Finds users likely to be long-term members
db.users.find(
    {
        $and: [
            { age: { $gte: 25 } },
            { "stats.total_sessions": { $gte: 100 } }
        ]
    },
    { username: 1, age: 1, "stats.total_sessions": 1, _id: 0 }
).sort({ age: -1 }).forEach(printjson); // Sort by age


//Searches for users with specific, aligned goals for customized coaching programs.(Matching the whole array)
db.users.find(
    { goals: {$all:["Lose weight", "Gain muscle"] }},
    { username: 1, goals: 1, _id: 0 } 
).forEach(printjson);

//Links users with their workout details for a complete view of their activities for personalized recommendations.
db.users.aggregate([
    {
        $lookup: {
            from: "workouts",
            localField: "username",
            foreignField: "username",
            as: "user_workouts"
        }
    },
    { $project: { username: 1, "user_workouts.exercises": 1, _id: 0 } } 
]).forEach(printjson);

//Total calories by goal
db.users.aggregate([
    { $match: { "stats.calories_burned": { $gte: 0 } } },
    { 
        $group: { 
            _id: "$goals", 
            total_calories: { $sum: "$stats.calories_burned" } 
        } 
    },
    { $sort: { total_calories: -1 } } // Sort by calories (descending)
]).forEach(printjson);

//Average age per goal
db.users.aggregate([
    { 
        $group: { 
            _id: "$goals", 
            avg_age: { $avg: "$age" } 
        } 
    },
    { 
        $project: { 
            fitness_goal: "$_id", 
            avg_age: 1, 
            _id: 0 
        } 
    }
]).forEach(printjson);

//First user created in each goal
db.users.aggregate([
    { $sort: { created_at: 1 } },
    { 
        $group: { 
            _id: "$goals", 
            first_user: { $first: "$username" } 
        } 
    }
]).forEach(printjson);

//Retrieve the third and fourth users with at least 50 sessions, sorted by session count. (Skip and Limit Users with High Sessions)
db.users.aggregate([
    { $match: { "stats.total_sessions": { $gte: 50 } } },
    { $sort: { "stats.total_sessions": -1 } }, 
    { $skip: 2 },
    { $limit: 2 }
]).forEach(printjson);

//Count the number of users per fitness goal.
db.users.aggregate([
    { 
        $group: { 
            _id: "$goals", 
            user_count: { $sum: 1 } 
        } 
    }
]).forEach(printjson);

//Total Time Spent on Workouts
db.workouts.aggregate([
    { $unwind: "$exercises" },
    { 
        $group: { 
            _id: "$exercises.type", 
            total_time: { $sum: "$exercises.duration" } 
        } 
    }
]).forEach(printjson);

//The top 5 workouts the highest average duration
db.workouts.aggregate([
    { $unwind: "$exercises" },
    { 
        $group: { 
            _id: "$exercises.type", 
            avg_duration: { $avg: "$exercises.duration" } 
        } 
    },
    { $sort: { avg_duration: -1 } },
    { $limit: 5 }
]).forEach(printjson);

//Minimum and Maximum Calories Burned per Workout Type
db.workouts.aggregate([
    { $unwind: "$exercises" },
    { $match: { "exercises.calories_burned": { $exists: true, $ne: null } } },
    { 
        $group: { 
            _id: "$exercises.type", 
            min_calories: { $min: "$exercises.calories" }, 
            max_calories: { $max: "$exercises.calories" }
        } 
    }
]).forEach(printjson);

//Count how many workouts each user has logged
db.workouts.aggregate([
    { 
        $group: { 
            _id: "$username", 
            total_workouts: { $count: {} }
        } 
    }
]).forEach(printjson);

//(Skip and Limit) Retrieve the 3rd and 4th most recent workouts, sorted by the workout date
db.workouts.aggregate([
    { $sort: { date: -1 } }, 
    { $skip: 2 }, 
    { $limit: 2 } 
]).forEach(printjson);