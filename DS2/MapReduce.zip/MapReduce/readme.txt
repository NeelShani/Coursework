The input data (input.txt) represents workout sessions for different users. 
Each line corresponds to one workout record with attributes separated by tabs:
Format: user_id  workout_type  calories_burned  date
Example: 1    Cardio    400    2024-09-10

The objective of the MapReduce job is to:
1. Filter out workouts that have burned fewer than 200 calories (non-trivial filtering in the Mapper).
2. Group the remaining workouts by their workout_type.
3. For each workout_type, compute two aggregations in the Reducer:
   - The total number of qualifying workout sessions of that type.
   - The total sum of calories burned for that type.
   
Finally, we output each workout_type, the total count of workouts of that type, and the sum of their calories.

This solves a grouping and aggregation problem, and the logic is more complex than a simple word count. The Mapper and Reducer both have about 10 lines of logic code, and we do not implement a Combiner.



INPUT DATA DESCRPTION
user_id    workout_type    calories_burned         date
     1            Cardio                     400                2024-09-10

user_id: Integer ID of the user (e.g., 1).
workout_type: The workout category (e.g., Cardio, Strength, Yoga).
calories_burned: Integer representing how many calories were burned in that session (e.g., 500).
date: The date the workout took place (e.g., 2024-09-10).


OUTPUT EXAMPLE
Cardio    3    1500
(Which means there are 3 qualifying Cardio workouts with a total of 1500 calories burned.)

#input.txt
1    Cardio    400    2024-09-10
2    Strength    180    2024-09-11
3    Yoga    300    2024-09-12
4    HIIT    250    2024-09-13
1    Cardio    100    2024-09-14
2    Strength    380    2024-09-15
5    Cardio    500    2024-09-16
3    Yoga    150    2024-09-17
4    HIIT    275    2024-09-18
5    Cardio    600    2024-09-19
(In this example, lines with calories_burned < 200 will be discarded by the mapper.)

#output.txt
Cardio    3    1500
HIIT    2    525
Strength    1    380
Yoga    1    300

Cardio: (400 + 500 + 600 = 1500) over 3 sessions
HIIT: (250 + 275 = 525) over 2 sessions
Strength: (380) over 1 session (180 was filtered out)
Yoga: (300) over 1 session (150 was filtered out)





COMPILE AND RUN

#adding to the user/...
hdfs dfs -put /home/f24_shaninee/assignments/mapreduce/input.txt /user/f24_shaninee/input.txt

#to check 
hdfs dfs -ls /user/f24_shaninee/

#remove current o/p
hdfs dfs -rm -r /user/f24_shaninee/output

#run mapreduce
hadoop jar MapReduce.jar MapReduce /user/f24_shaninee/input.txt /user/f24_shaninee/output

#print output
hdfs dfs -cat /user/f24_shaninee/output/part-r-00000