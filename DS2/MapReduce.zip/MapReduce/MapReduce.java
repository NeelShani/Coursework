import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MapReduce {

    // Mapper Class
    // Each line: user_id<TAB>workout_type<TAB>calories_burned<TAB>date
    // Filter out workouts with calories_burned < 200 and emit type as key, calories as value
    public static class WorkoutMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
        private Text workoutType = new Text();
        private IntWritable caloriesOut = new IntWritable();

        @Override
        public void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {
            // Parse line
            String line = value.toString();
            String[] parts = line.split("\\s+");
            // Expecting 4 parts: user_id, workout_type, calories, date
            if (parts.length == 4) {
                String type = parts[1];
                int calories = 0;
                try { calories = Integer.parseInt(parts[2]); } catch (NumberFormatException e) { return; }
                // Filter condition: only process if calories >= 200
                if (calories >= 200) {
                    workoutType.set(type);
                    caloriesOut.set(calories);
                    context.write(workoutType, caloriesOut);
                }
            }
        }
    }

    // Reducer Class
    // Input: key=workout_type, values=calories of each qualifying workout
    // Output: key=workout_type, value="count sum"
    public static class WorkoutReducer extends Reducer<Text, IntWritable, Text, Text> {
        private Text result = new Text();

        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {
            int count = 0;
            int sum = 0;
            for (IntWritable val : values) {
                sum += val.get();
                count++;
            }
            // Output: type, count, sum
            result.set(count + "\t" + sum);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.err.println("Usage: MapReduce <input> <output>");
            System.exit(2);
        }
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Workout Aggregation");
        job.setJarByClass(MapReduce.class);
        job.setMapperClass(WorkoutMapper.class);
        job.setReducerClass(WorkoutReducer.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
