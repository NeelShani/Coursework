// Single CREATE statement to insert 10 Users and 10 Workouts with 15 Relationships
CREATE
    // Users
    (u1:User {user_id: 1, name: 'John Doe', age: 28, email: 'john.doe@example.com', goals: ['Lose weight', 'Improve stamina']}),
    (u2:User {user_id: 2, name: 'Jane Smith', age: 25, email: 'jane.smith@example.com', goals: ['Gain muscle']}),
    (u3:User {user_id: 3, name: 'Mike Johnson', age: 32, email: 'mike.johnson@example.com', goals: ['Maintain fitness']}),
    (u4:User {user_id: 4, name: 'Alice Brown', age: 30, email: 'alice.brown@example.com', goals: ['Run a marathon']}),
    (u5:User {user_id: 5, name: 'Emma White', age: 27, email: 'emma.white@example.com', goals: ['Lose weight', 'Maintain fitness']}),
    (u6:User {user_id: 6, name: 'Charlie Black', age: 35, email: 'charlie.black@example.com', goals: ['Build endurance']}),
    (u7:User {user_id: 7, name: 'David Green', age: 40, email: 'david.green@example.com', goals: ['Gain muscle', 'Improve flexibility']}),
    (u8:User {user_id: 8, name: 'Sophia Lee', age: 22, email: 'sophia.lee@example.com', goals: ['Stay active']}),
    (u9:User {user_id: 9, name: 'Oliver Kim', age: 29, email: 'oliver.kim@example.com', goals: ['Gain muscle', 'Improve stamina']}),
    (u10:User {user_id: 10, name: 'Mia Clark', age: 24, email: 'mia.clark@example.com', goals: ['Maintain fitness', 'Run a marathon']}),

    // Workouts
    (w1:Workout {workout_id: 101, type: 'Cardio', duration: '00:45', date: date('2024-09-10'), calories_burned: 400}),
    (w2:Workout {workout_id: 102, type: 'Strength Training', duration: '01:15', date: date('2024-09-11'), calories_burned: 380}),
    (w3:Workout {workout_id: 103, type: 'Yoga', duration: '00:60', date: date('2024-09-12'), calories_burned: 300}),
    (w4:Workout {workout_id: 104, type: 'HIIT', duration: '00:30', date: date('2024-09-13'), calories_burned: 250}),
    (w5:Workout {workout_id: 105, type: 'Endurance', duration: '02:00', date: date('2024-09-14'), calories_burned: 800}),
    (w6:Workout {workout_id: 106, type: 'Cardio', duration: '00:50', date: date('2024-09-15'), calories_burned: 500}),
    (w7:Workout {workout_id: 107, type: 'Yoga', duration: '01:00', date: date('2024-09-16'), calories_burned: 200}),
    (w8:Workout {workout_id: 108, type: 'Cardio', duration: '00:40', date: date('2024-09-17'), calories_burned: 350}),
    (w9:Workout {workout_id: 109, type: 'Strength Training', duration: '01:30', date: date('2024-09-18'), calories_burned: 220}),
    (w10:Workout {workout_id: 110, type: 'HIIT', duration: '00:25', date: date('2024-09-19'), calories_burned: 250}),

    // Relationships: FRIENDS_WITH
    (u1)-[:FRIENDS_WITH]->(u2),
    (u1)-[:FRIENDS_WITH]->(u3),
    (u2)-[:FRIENDS_WITH]->(u4),
    (u3)-[:FRIENDS_WITH]->(u5),
    (u4)-[:FRIENDS_WITH]->(u6),
    (u5)-[:FRIENDS_WITH]->(u7),
    (u6)-[:FRIENDS_WITH]->(u8),
    (u7)-[:FRIENDS_WITH]->(u9),
    (u8)-[:FRIENDS_WITH]->(u10),

    // Relationships: HAS_WORKOUT
    (u1)-[:HAS_WORKOUT]->(w1),
    (u1)-[:HAS_WORKOUT]->(w2),
    (u2)-[:HAS_WORKOUT]->(w3),
    (u2)-[:HAS_WORKOUT]->(w4),
    (u3)-[:HAS_WORKOUT]->(w5),
    (u3)-[:HAS_WORKOUT]->(w6),
    (u4)-[:HAS_WORKOUT]->(w7),
    (u4)-[:HAS_WORKOUT]->(w8),
    (u5)-[:HAS_WORKOUT]->(w9),
    (u5)-[:HAS_WORKOUT]->(w10);
    

// Create a unique constraint on User.user_id to ensure uniqueness. Ensures that each User has a unique user_id.
CREATE CONSTRAINT unique_user_id IF NOT EXISTS 
FOR (u:User) 
REQUIRE u.user_id IS UNIQUE;


// Create an index on Workout.type to improve query performance when filtering by workout type. Enhances the performance of queries that filter Workouts by their type.
CREATE INDEX workout_type_index IF NOT EXISTS 
FOR (w:Workout) 
ON (w.type);


//Find users who have burned more than 500 calories and list their workouts. also the catagories for user more than 3000 and 1000.
MATCH (u:User)-[:HAS_WORKOUT]->(w:Workout)
WITH u, COUNT(w) AS total_workouts, SUM(w.calories_burned) AS total_calories
WHERE total_calories > 500
RETURN 
    u.name AS User,
    total_workouts,
    total_calories,
    CASE 
        WHEN total_calories > 3000 THEN 'Elite'
        WHEN total_calories > 1000 THEN 'Active'
        ELSE 'Moderate'
    END AS activity_level
ORDER BY total_calories DESC;



// Find all users and optionally their friends, demonstrating OPTIONAL MATCH and collect(). Users without friends will still appear with an empty Friends list.
MATCH (u:User)
OPTIONAL MATCH (u)-[:FRIENDS_WITH]->(f:User)
RETURN u.name AS User, collect(f.name) AS Friends
ORDER BY User;


//Find users whose email contains 'example' and name starts with 'John', using string operations and regular expressions.
MATCH (u:User)
WHERE u.email CONTAINS 'example' AND u.name STARTS WITH 'John'
RETURN u.name, u.email
ORDER BY u.name;



// Find users with emails matching a specific regex and count their workouts, using regular expressions and aggregations, Retrieves users with emails ending in '@example.com' and counts the number of workouts each has, ordered by workout count in descending order.

MATCH (u:User)-[:HAS_WORKOUT]->(w:Workout)
WHERE u.email =~ '.*@example\\.com'
RETURN u.name, COUNT(w) AS workout_count
ORDER BY workout_count DESC;


// Find users with more than one goal using pattern conditions (EXISTS, IN) and list operations. who have more than one goal and 'Gain muscle' as one of their goals, displaying their first and last goals, ordered by name.

MATCH (u:User)
WHERE size(u.goals) > 1 AND 'Gain muscle' IN u.goals
RETURN u.name, u.goals, head(u.goals) AS first_goal, last(u.goals) AS last_goal
ORDER BY u.name;


// Find the shortest path between two users using variable length paths. Here, determines the shortest friendship path between user 1 (John Doe) and user 5 (Emma White).
MATCH path = shortestPath((u1:User {user_id: 1})-[:FRIENDS_WITH*]-(u5:User {user_id: 5}))
RETURN path;



// Perform a date/time interval query to find workouts within a specific date range. ->workouts that took place between September 10, 2024, and September 15, 2024, ordered by date in ascending order.
MATCH (w:Workout)
WHERE w.date >= date('2024-09-10') AND w.date <= date('2024-09-15')
RETURN w.workout_id, w.type, w.date, w.calories_burned
ORDER BY w.date ASC;


// Use CASE expressions to categorize users based on age. Assigns an age category ('Young', 'Adult', 'Senior') to each user based on their age, ordered by age in descending order.

MATCH (u:User)
RETURN 
    u.name, 
    u.age,
    CASE 
        WHEN u.age < 25 THEN 'Young'
        WHEN u.age >= 25 AND u.age < 35 THEN 'Adult'
        ELSE 'Senior'
    END AS age_group
ORDER BY u.age DESC;



// Cypher Write and Read/Write Queries

// Write: Create a new workout for a user, using MATCH and CREATE with RETURN. Adds a new 'Pilates' workout session for the user with user_id 1 and returns the user's name along with the new workout details.

MATCH (u:User {user_id: 1})
CREATE (u)-[:HAS_WORKOUT]->(w:Workout {workout_id: 111, type: 'Pilates', duration: '01:00', date: date('2024-09-20'), calories_burned: 250})
RETURN u.name, w;

// Write: Delete a specific workout relationship using MATCH and DELETE.-> Removes the 'HAS_WORKOUT' relationship between user 2 (Jane Smith) and workout 102 (Strength Training).
MATCH (u:User {user_id: 2})-[r:HAS_WORKOUT]->(w:Workout {workout_id: 102})
DELETE r;



// Write: Set a new property for a user using MATCH and SET. Marks user 3 (Mike Johnson) as a premium member by setting the 'premium_member' property to true and returns the updated details.

MATCH (u:User {user_id: 3})
SET u.premium_member = true
RETURN u.name, u.premium_member;


// Write: Remove a property from a workout using MATCH and REMOVE. Deletes the 'calories_burned' property from workout session 105 (Endurance) and returns the workout ID and the removed property (which will be null).

MATCH (w:Workout {workout_id: 105})
REMOVE w.calories_burned
RETURN w.workout_id, w.calories_burned;



// Write: Detach delete a user and all their relationships using MATCH and DETACH DELETE. Completely removes user 10 (Mia Clark) and all relationships connected to them from the graph.

MATCH (u:User {user_id: 10})
DETACH DELETE u;


// Write: Add a new friend relationship using MATCH and CREATE. Establishes a new 'FRIENDS_WITH' relationship between user 1 (John Doe) and user 4 (Alice Brown), then returns their names.

MATCH (u1:User {user_id: 1}), (u4:User {user_id: 4})
CREATE (u1)-[:FRIENDS_WITH]->(u4)
RETURN u1.name, u4.name;


// Write: Update multiple users' goals using MATCH and SET with WHERE criteria. Adds 'Increase flexibility' to the goals of all users older than 30 and returns their names and updated goals.
MATCH (u:User)
WHERE u.age > 30
SET u.goals = u.goals + ['Increase flexibility']
RETURN u.name, u.goals;



// Write Query 9: Update a relationship property using MATCH and SET. Adds a 'notes' property to the 'HAS_WORKOUT' relationship between user 5 (Emma White) and workout 109, then returns the user's name, workout type, and the new notes.
MATCH (u:User {user_id: 5})-[r:HAS_WORKOUT]->(w:Workout {workout_id: 109})
SET r.notes = 'Strength training session focused on upper body'
RETURN u.name, w.type, r.notes;



// Write Query 10: Remove a relationship property using MATCH and REMOVE. Removes the 'notes' property from the 'HAS_WORKOUT' relationship between user 1 (John Doe) and workout 101, then returns the user's name, workout type, and the removed property (which will be null).
MATCH (u:User {user_id: 1})-[r:HAS_WORKOUT]->(w:Workout {workout_id: 101})
REMOVE r.notes
RETURN u.name, w.type, r.notes;