import psycopg2
import redis
import json
from decimal import Decimal
from datetime import date

# PostgreSQL connection
pg_conn = psycopg2.connect(
    dbname="f24_shaninee",
    user="f24_shaninee",
    password="39YaDG65nx",
    host="nosql.felk.cvut.cz"
)

# Redis connection
redis_conn = redis.StrictRedis(
    host="nosql.felk.cvut.cz",
    port=6452,
    db=0,
    password="39YaDG65nx"
)

# Function to execute query with Redis caching
def execute_query_with_cache(query_key, query, fetch_all=True):
    # Check if query result exists in Redis cache
    cached_result = redis_conn.get(query_key)
    if cached_result:
        print(f"Result for '{query_key}' found in cache.")
        return json.loads(cached_result)
    else:
        print(f"Result for '{query_key}' not found in cache. Executing query...")
        with pg_conn.cursor() as cursor:
            cursor.execute(query)
            result = cursor.fetchall() if fetch_all else cursor.fetchone()
            # Cache the query result in Redis with a timeout (e.g., 1 hour)
            redis_conn.setex(query_key, 3600, json.dumps(result))
            return result

# Queries
queries = {
    "total_calories_burned": """
        SELECT user_id, SUM(calories_burned) AS total_calories
        FROM Workout_Log
        GROUP BY user_id
        ORDER BY total_calories DESC;
    """,
    "total_workouts_performed": """
        SELECT workout_name, COUNT(*) AS total_performed
        FROM Workout_Log
        GROUP BY workout_name
        ORDER BY total_performed DESC
        LIMIT 10;
    """,
    "users_by_fitness_goal": """
        SELECT name, age, weight_kg, fitness_goal
        FROM "User"
        WHERE fitness_goal = 'Lose weight';
    """
}

# Execute and print results
for key, query in queries.items():
    result = execute_query_with_cache(key, query)
    print(f"\nResult for {key}:\n", result)

# Close PostgreSQL connection after use
pg_conn.close()



# import redis
# import psycopg2
# import json
# from decimal import Decimal
# from datetime import date

# # Initialize Redis and PostgreSQL connections
# redis_client = redis.StrictRedis(host='nosql.felk.cvut.cz', port=6452, db=0, password='39YaDG65nx')
# postgres_conn = psycopg2.connect("dbname='f24_shaninee' user='f24_shaninee' password='39YaDG65nx' host='localhost'")
# cursor = postgres_conn.cursor()

# # Function to serialize Decimal and date objects
# def serialize_result(result):
#     serialized = []
#     for row in result:
#         serialized_row = []
#         for value in row:
#             if isinstance(value, Decimal):
#                 serialized_row.append(float(value))  # Convert Decimal to float
#             elif isinstance(value, date):
#                 serialized_row.append(value.isoformat())  # Convert date to ISO format string
#             else:
#                 serialized_row.append(value)  # Keep other types as is
#         serialized.append(serialized_row)
#     return serialized

# # Function to execute SQL queries with Redis caching
# def execute_with_cache(query, cache_key):
#     # Check Redis cache
#     cached_result = redis_client.get(cache_key)
#     if cached_result:
#         print("Result retrieved from cache.")
#         return json.loads(cached_result)  # Return cached result

#     # Execute SQL query if not in cache
#     cursor.execute(query)
#     result = cursor.fetchall()

#     # Serialize the result to handle Decimal and date types
#     serialized_result = serialize_result(result)

#     # Store the result in cache for future use
#     redis_client.set(cache_key, json.dumps(serialized_result))
#     print("Result retrieved from database and stored in cache.")
#     return serialized_result
# # SQL Queries with Redis caching

# # 1. Get All Available Cars for Confirmed Bookings
# query1 = """
    
#         SELECT user_id, SUM(calories_burned) AS total_calories
#         FROM Workout_Log
#         GROUP BY user_id
#         ORDER BY total_calories DESC;
# """
# result1 = execute_with_cache(query1, "total_calories_burned")

# # 2. Find Available Sedan Cars in a Price Range
# query2 = """
#         SELECT workout_name, COUNT(*) AS total_performed
#         FROM Workout_Log
#         GROUP BY workout_name
#         ORDER BY total_performed DESC
#         LIMIT 10;
# """
# result2 = execute_with_cache(query2, "total_workouts_performed")

# # 3. Calculate Total Payments for a Specific Booking
# query3 = """
#         SELECT name, age, weight_kg, fitness_goal
#         FROM "User"
#         WHERE fitness_goal = 'Lose weight';
# """
# result3 = execute_with_cache(query3, "users_by_fitness_goal")

# # Output Results
# print("Results for Query 1:", result1)
# print("Results for Query 2:", result2)
# print("Results for Query 3:", result3)

# # Close database connection
# cursor.close()
# postgres_conn.close()