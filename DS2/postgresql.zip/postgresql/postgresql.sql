CREATE TABLE "User"(
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    age INT, 
    weight_kg DECIMAL(5,2),
    height_cm INT,
    fitness_goal VARCHAR(255)
);


INSERT INTO "User"(name, email, password, age, weight_kg, height_cm, fitness_goal)
VALUES
    ('John Doe', 'john.doe@example.com', 'pass123', 28, 78.5, 1.80, 'Lose weight'),
    ('Jane Smith', 'jane.smith@example.com', 'strongPass1', 25, 65.0, 170, 'Gain muscle'),
    ('Mike Johnson', 'mike.j@example.com', 'mikeStrong45', 32, 85.0, 175, 'Maintain fitness'),
    ('Emily Brown', 'emily.brown@example.com', 'password123', 29, 70.5, 165, 'Lose weight'),
    ('David Lee', 'david.lee@example.com', 'david@strong', 35, 90.0, 180, 'Gain muscle'),
    ('Sophia Martinez', 'sophia.martinez@example.com', 'sophiaFit', 26, 60.0, 162, 'Increase flexibility'),
    ('James Williams', 'james.williams@example.com', 'jamesPower', 40, 95.0, 185, 'Lose weight'),
    ('Isabella Davis', 'isabella.davis@example.com', 'bella2024', 22, 55.0, 160, 'Gain muscle'),
    ('Mason Anderson', 'mason.anderson@example.com', 'masonPro2024', 30, 80.0, 170, 'Improve endurance'),
    ('Olivia Thomas', 'olivia.thomas@example.com', 'oliviaStrong', 27, 58.5, 163, 'Maintain fitness'),
    ('Lucas Taylor', 'lucas.taylor@example.com', 'lucasFlex', 36, 92.0, 178, 'Increase flexibility'),
    ('Ava Scott', 'ava.scott@example.com', 'avaGym123', 24, 62.5, 168, 'Lose weight'),
    ('Ethan Carter', 'ethan.carter@example.com', 'ethanFit2024', 33, 88.0, 175, 'Gain muscle'),
    ('Mia Phillips', 'mia.phillips@example.com', 'miaFitJourney', 31, 63.0, 167, 'Maintain fitness'),
    ('Liam Moore', 'liam.moore@example.com', 'liamWorkout', 29, 77.0, 169, 'Improve endurance'),
    ('Amelia Cooper', 'amelia.cooper@example.com', 'ameliaYoga', 28, 57.5, 162, 'Increase flexibility'),
    ('Noah Brooks', 'noah.brooks@example.com', 'noahGym2024', 34, 91.0, 180, 'Gain muscle'),
    ('Ella King', 'ella.king@example.com', 'ellaFitPro', 26, 56.0, 164, 'Lose weight'),
    ('Jacob Young', 'jacob.young@example.com', 'jacobStrong', 37, 86.0, 176, 'Maintain fitness'),
    ('Harper Turner', 'harper.turner@example.com', 'harperPush123', 23, 59.5, 161, 'Gain muscle'),
    ('Daniel Hill', 'daniel.hill@example.com', 'danielEndurance', 31, 84.0, 173, 'Improve endurance'),
    ('Aiden Green', 'aiden.green@example.com', 'aidenFlex123', 27, 78.0, 168, 'Increase flexibility'),
    ('Charlotte Adams', 'charlotte.adams@example.com', 'charlotteYoga', 25, 58.0, 165, 'Maintain fitness'),
    ('Elijah Nelson', 'elijah.nelson@example.com', 'elijahPower', 38, 93.0, 182, 'Lose weight'),
    ('Sofia Baker', 'sofia.baker@example.com', 'sofiaGain2024', 29, 66.5, 167, 'Gain muscle'),
    ('Benjamin Harris', 'benjamin.harris@example.com', 'benPower', 35, 87.0, 177, 'Maintain fitness'),
    ('Abigail Clark', 'abigail.clark@example.com', 'abigailRun', 22, 54.0, 160, 'Improve endurance'),
    ('Henry Wright', 'henry.wright@example.com', 'henryStrength', 32, 89.5, 179, 'Gain muscle'),
    ('Scarlett Walker', 'scarlett.walker@example.com', 'scarlettFlex2024', 28, 61.5, 166, 'Increase flexibility'),
    ('Sebastian Hall', 'sebastian.hall@example.com', 'sebastianFit', 40, 92.5, 181, 'Lose weight'),
    ('Avery Allen', 'avery.allen@example.com', 'averyYoga123', 30, 64.0, 170, 'Maintain fitness'),
    ('Jack King', 'jack.king@example.com', 'jackStrength', 27, 75.5, 169, 'Improve endurance'),
    ('Ella Peterson', 'ella.peterson@example.com', 'ellaGym', 25, 60.0, 164, 'Gain muscle'),
    ('Alexander Mitchell', 'alexander.mitchell@example.com', 'alexFit', 36, 88.0, 178, 'Maintain fitness'),
    ('Zoe Ward', 'zoe.ward@example.com', 'zoeStrong2024', 26, 57.0, 163, 'Lose weight'),
    ('Isaac Lewis', 'isaac.lewis@example.com', 'isaacPower', 33, 90.0, 181, 'Gain muscle'),
    ('Aria Murphy', 'aria.murphy@example.com', 'ariaYoga123', 31, 62.5, 165, 'Increase flexibility'),
    ('Michael Collins', 'michael.collins@example.com', 'michaelWorkout', 39, 94.0, 182, 'Lose weight'),
    ('Lily Sanchez', 'lily.sanchez@example.com', 'lilyFit2024', 28, 59.0, 160, 'Maintain fitness'),
    ('William Bell', 'william.bell@example.com', 'willStrength', 30, 82.5, 174, 'Improve endurance'),
    ('Grace Rivera', 'grace.rivera@example.com', 'graceYoga2024', 29, 63.0, 168, 'Increase flexibility'),
    ('Matthew Cox', 'matthew.cox@example.com', 'mattPower', 27, 85.0, 177, 'Gain muscle'),
    ('Chloe Richardson', 'chloe.richardson@example.com', 'chloeFitPro', 32, 58.0, 162, 'Lose weight'),
    ('Samuel Wood', 'samuel.wood@example.com', 'samStrong', 35, 91.0, 179, 'Maintain fitness'),
    ('Aubrey Foster', 'aubrey.foster@example.com', 'aubreyYoga123', 24, 60.5, 165, 'Increase flexibility'),
    ('Gabriel Powell', 'gabriel.powell@example.com', 'gabeEndurance', 31, 83.0, 172, 'Improve endurance'),
    ('Lillian Brooks', 'lillian.brooks@example.com', 'lillianFit', 26, 55.0, 161, 'Lose weight'),
    ('Joshua Russell', 'joshua.russell@example.com', 'joshPower', 38, 87.5, 178, 'Gain muscle');
  
CREATE TABLE Workout_Log (
    log_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES "User"(user_id) ON DELETE CASCADE,
    workout_name VARCHAR(100),
    set_no INT,
    reps INT,
    duration_min INT, 
    calories_burned DECIMAL(5,2),
    workout_data JSONB);
    
INSERT INTO Workout_Log (user_id, workout_name, set_no, reps, duration_min, calories_burned, workout_data)
VALUES 
    (1, 'Running', 0, 0, 30, 300.0, '{"distance": "5km", "location": "Park"}'),
    (2, 'Bench Press', 4, 10, 45, 250.0, '{"equipment": "Barbell", "weight_per_set": "50kg"}'),
    (3, 'Cycling', 0, 0, 60, 600.0, '{"distance": "20km", "terrain": "Hilly"}'),
    (1, 'Push-ups', 3, 15, 20, 150.0, '{"equipment": "None", "intensity": "High"}'),
    (4, 'Swimming', 0, 0, 40, 350.0, '{"distance": "1km", "pool": "Indoor"}'),
    (5, 'Squats', 5, 12, 30, 200.0, '{"equipment": "None", "weight": "Bodyweight"}'),
    (6, 'Deadlift', 3, 8, 50, 400.0, '{"equipment": "Barbell", "weight_per_set": "100kg"}'),
    (7, 'Jump Rope', 0, 0, 20, 220.0, '{"revolutions": "2000"}'),
    (8, 'Rowing', 0, 0, 30, 330.0, '{"distance": "5km", "location": "Gym"}'),
    (9, 'Plank', 0, 0, 10, 80.0, '{"duration_per_set": "2 minutes"}'),
    (10, 'Pull-ups', 4, 8, 15, 120.0, '{"equipment": "Pull-up bar"}'),
    (11, 'Running', 0, 0, 30, 300.0, '{"distance": "5km", "location": "Park"}'),
    (12, 'Lunges', 4, 12, 25, 180.0, '{"equipment": "Dumbbells", "weight": "10kg"}'),
    (13, 'Yoga', 0, 0, 60, 180.0, '{"style": "Vinyasa"}'),
    (14, 'Boxing', 0, 0, 45, 450.0, '{"type": "Heavy bag"}'),
    (15, 'Mountain Climbers', 3, 20, 15, 170.0, '{"intensity": "High"}'),
    (16, 'Burpees', 4, 10, 20, 200.0, '{"intensity": "High"}'),
    (17, 'Elliptical', 0, 0, 40, 320.0, '{"resistance_level": "Medium"}'),
    (18, 'Kettlebell Swings', 4, 15, 20, 230.0, '{"weight": "20kg"}'),
    (19, 'Stair Climbing', 0, 0, 30, 400.0, '{"steps": "1000"}'),
    (20, 'Dumbbell Curls', 4, 12, 20, 120.0, '{"weight_per_set": "15kg"}'),
    (21, 'Treadmill Running', 0, 0, 30, 300.0, '{"distance": "5km", "speed": "10km/h"}'),
    (22, 'Leg Press', 4, 10, 35, 250.0, '{"equipment": "Leg Press Machine", "weight_per_set": "150kg"}'),
    (23, 'CrossFit', 0, 0, 60, 550.0, '{"workout_type": "AMRAP"}'),
    (24, 'Chin-ups', 3, 8, 15, 130.0, '{"equipment": "Pull-up bar"}'),
    (25, 'Sprint Intervals', 0, 0, 20, 280.0, '{"distance_per_sprint": "200m", "rest_time": "30s"}'),
    (26, 'Dips', 3, 12, 15, 110.0, '{"equipment": "Parallel bars"}'),
    (27, 'Wall Sits', 0, 0, 10, 90.0, '{"duration_per_set": "1 minute"}'),
    (28, 'Rowing Machine', 0, 0, 30, 330.0, '{"distance": "6km", "resistance_level": "High"}'),
    (29, 'Jumping Jacks', 0, 0, 10, 100.0, '{"reps": "200"}'),
    (30, 'Medicine Ball Slams', 4, 15, 20, 210.0, '{"weight": "10kg"}'),
    (31, 'Leg Raises', 3, 12, 15, 90.0, '{"equipment": "None"}'),
    (32, 'Bicycle Crunches', 4, 20, 10, 110.0, '{"intensity": "Medium"}'),
    (33, 'Plyometrics', 0, 0, 30, 320.0, '{"exercises": "Box jumps, lateral jumps"}'),
    (34, 'Zumba', 0, 0, 60, 400.0, '{"style": "Latin"}'),
    (35, 'TRX Rows', 4, 12, 25, 160.0, '{"equipment": "TRX"}'),
    (36, 'Skiing', 0, 0, 90, 700.0, '{"distance": "15km"}'),
    (37, 'Powerlifting', 3, 6, 60, 500.0, '{"lifts": "Squat, Bench, Deadlift"}'),
    (38, 'Barbell Rows', 4, 10, 40, 240.0, '{"weight_per_set": "60kg"}'),
    (39, 'Turkish Get-Up', 4, 8, 20, 180.0, '{"weight": "15kg"}'),
    (40, 'Step-ups', 3, 12, 20, 160.0, '{"height": "50cm"}'),
    (41, 'Rock Climbing', 0, 0, 60, 600.0, '{"type": "Bouldering"}'),
    (42, 'Russian Twists', 3, 15, 10, 90.0, '{"weight": "5kg"}'),
    (43, 'Farmers Walk', 0, 0, 15, 150.0, '{"weight_per_hand": "30kg"}'),
    (44, 'Bodyweight Circuit', 0, 0, 30, 300.0, '{"exercises": "Push-ups, squats, burpees"}'),
    (45, 'Jump Squats', 3, 15, 20, 200.0, '{"height": "40cm"}'),
    (46, 'Handstands', 0, 0, 20, 150.0, '{"duration_per_set": "1 minute"}'),
    (47, 'Hiking', 0, 0, 120, 600.0, '{"elevation_gain": "500m"}'),
    (48, 'Battle Ropes', 3, 10, 15, 180.0, '{"length": "10m"}');


SELECT workout_name, workout_data -> 'distance' AS distance
FROM Workout_Log
WHERE workout_name ='Running';

SELECT workout_name, workout_data
FROM Workout_Log
WHERE workout_data @> '{"equipment": "Barbell"}';

SELECT workout_name, workout_data->>'weight_per_set' AS weight
FROM Workout_Log
WHERE workout_name = 'Bench Press';

SELECT workout_name, workout_data->>'distance' AS distance
FROM Workout_Log
WHERE workout_data ? 'distance';



