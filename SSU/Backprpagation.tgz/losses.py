import numpy as np

class LossCrossEntropy(object):
    def __init__(self, name):
        super(LossCrossEntropy, self).__init__()
        self.name = name

    def forward(self, X, T):
        """
        Forward message.
        :param X: loss inputs (outputs of the previous layer), shape (n_samples, n_inputs), n_inputs is the same as
        the number of classes
        :param T: one-hot encoded targets, shape (n_samples, n_inputs)
        :return: layer output, shape (n_samples, 1)
        """
        # TODO: Implement
        epsilon = 1e-12
        X_clipped = np.clip(X, epsilon, 1.0 - epsilon)
        loss = -np.sum(T* np.log(X_clipped), axis=1, keepdims=True)
        return loss

    def delta(self, X, T):
        """
        Computes delta vector for the output layer.
        :param X: loss inputs (outputs of the previous layer), shape (n_samples, n_inputs), n_inputs is the same as
        the number of classes
        :param T: one-hot encoded targets, shape (n_samples, n_inputs)
        :return: delta vector from the loss layer, shape (n_samples, n_inputs)
        """
        # TODO: Implement
        delta = -T/X
        return delta


class LossCrossEntropyForSoftmaxLogits(object):
    def __init__(self, name):
        super(LossCrossEntropyForSoftmaxLogits, self).__init__()
        self.name = name

    def forward(self, X, T):
        """
        Forward message.
        :param X: loss inputs (outputs of the previous layer), shape (n_samples, n_inputs), n_inputs is the same as
        the number of classes
        :param T: one-hot encoded targets, shape (n_samples, n_inputs)
        :return: layer output, shape (n_samples, 1)
        """
        # TODO: Implement
        X_stable = X - np.max(X, axis=1, keepdims=True)  # Subtract max for numerical stability
        exp_X = np.exp(X_stable)  # Compute exponentials
        softmax = exp_X / np.sum(exp_X, axis=1, keepdims=True)  # Normalize to get softmax probabilities

        # Compute the cross-entropy loss
        epsilon = 1e-12  # to prevent log(0)
        softmax_clipped = np.clip(softmax, epsilon, 1.0 - epsilon)  # Prevent log(0)
        loss = -np.sum(T * np.log(softmax_clipped), axis=1, keepdims=True)
        return loss
    def delta(self, X, T):
        """
        Computes delta vector for the output layer.
        :param X: loss inputs (outputs of the previous layer), shape (n_samples, n_inputs), n_inputs is the same as
        the number of classes
        :param T: one-hot encoded targets, shape (n_samples, n_inputs)
        :return: delta vector from the loss layer, shape (n_samples, n_inputs)
        """
        # TODO: Implement
        exp_X = np.exp(X - np.max(X, axis=1, keepdims=True))  # Stabilized softmax
        softmax = exp_X / np.sum(exp_X, axis=1, keepdims=True)
        return softmax - T