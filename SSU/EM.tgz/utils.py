#!/usr/bin/env python3
import os
import urllib.request
import gzip
import io
import numpy as np
import pickle
from pathlib import Path
import json
from typing import Dict, Any, Tuple
import matplotlib.pyplot as plt

def save_data_to_buffer(data: Dict[Any, Any], output_file_path: str) -> None:
    """
    Save a dictionary to a binary buffer and write it to a file.
    """
    buffer = io.BytesIO()
    pickle.dump(data, buffer)
    buffer.seek(0)
    
    output_file_path = Path(output_file_path)
    output_file_path.write_bytes(buffer.getvalue())
    
def load_data_from_buffer(input_file_path: str) -> Dict[Any, Any]:
    """
    Load a dictionary from a binary buffer stored in a file.
    """
    input_file_path = Path(input_file_path)
    buffer = io.BytesIO(input_file_path.read_bytes())
    buffer.seek(0)
    
    data = pickle.load(buffer)
    return data
    
def read_input(input_path: str) -> dict:
    with open(input_path, "r") as file:
        data = json.load(file)
    
    def convert_to_numpy(d):
        if isinstance(d, dict):
            return {k: convert_to_numpy(v) for k, v in d.items()}
        elif isinstance(d, list):
            try:
                return np.array(d)
            except ValueError:
                return d
        else:
            return d
    
    return convert_to_numpy(data)

def load_MNIST(brute=False):
    """
    Loads MNIST dataset. If not present locally, the dataset is downloaded from Yann LeCun's site.
    The dataset consists of 60k training and 10k testing samples of 28x28 grayscale images. 
    The inputs are standardized and the output labels are one-hot encoded.
    """
    IMAGE_SIZE = 28
    N_CLASSES = 10

    if brute:
        files = {
            'X_train': ('/local/dataset/train-images-idx3-ubyte.gz', 60000),
            'T_train': ('/local/dataset/train-labels-idx1-ubyte.gz', 60000),
            'X_test': ('/local/dataset/t10k-images-idx3-ubyte.gz', 10000),
            'T_test': ('/local/dataset/t10k-labels-idx1-ubyte.gz', 10000),
        }
    else:
        files = {
            'X_train': ('train-images-idx3-ubyte.gz', 60000),
            'T_train': ('train-labels-idx1-ubyte.gz', 60000),
            'X_test': ('t10k-images-idx3-ubyte.gz', 10000),
            'T_test': ('t10k-labels-idx1-ubyte.gz', 10000),
        }
        
    data = {}
    for label, (name, n_images) in files.items():
        if not os.path.exists(name):
            print('downloading: {}'.format(name))
            urllib.request.urlretrieve('https://raw.githubusercontent.com/fgnt/mnist/master/{}'.format(name), name)
        with gzip.open(name) as bytestream:
            if label.startswith('X'):
                bytestream.read(16)  # header
                data[label] = (np.frombuffer(bytestream.read(IMAGE_SIZE * IMAGE_SIZE * n_images),
                                             dtype=np.uint8).astype(np.float32) / 255.0).reshape(n_images, -1)
            else:
                bytestream.read(8)  # header
                classes = np.frombuffer(bytestream.read(n_images), dtype=np.uint8).astype(np.int64)
                onehot = np.zeros((len(classes), N_CLASSES), dtype=np.float32)
                onehot[np.arange(len(classes)), classes] = 1
                data[label] = onehot

    X_train, T_train, X_test, T_test = [data[label] for label in ['X_train', 'T_train', 'X_test', 'T_test']]
    X = np.concatenate([X_train, X_test], axis=0)


    # Flatten one-hot encoding to integer labels        
    y = np.concatenate([T_train, T_test], axis=0)
    y = np.argmax(y, axis=1)
    
    return X, y

def visualize_MNIST():
    """
    TODO
    """
    X, y = load_MNIST()
    plt.figure(figsize=(10, 10))
    num_samples = 10
    classes = 10
    images = []
    for c in range(classes):
        X_ = X[y == c]
        for i in range(num_samples):
            plt.subplot(10, num_samples, (c)*10+(i + 1))
            plt.imshow(X_[i].reshape(28, 28), cmap="gray")
            plt.axis("off")
    plt.tight_layout()
    plt.show()

def plot_prior(prior_distribution, title=''):
    """
    TODO
    """
    from matplotlib.offsetbox import OffsetImage, AnnotationBbox
    X, y = load_MNIST()
    images = [X[y==c][0].reshape(28,28) for c in range(len(np.unique(y)))]
    
    fig, ax = plt.subplots(figsize=(10, 6))

    # Plot the stairs for the prior distribution
    ax.stairs(prior_distribution, np.arange(len(prior_distribution) + 1), fill=True, alpha=0.5)
    ax.set_ylabel("Probability", fontsize=12)
    ax.set_title(title, fontsize=14)

    # Add class images on the X-axis
    for i, img in enumerate(images):
        imagebox = OffsetImage(img, zoom=0.8, cmap="gray")
        ab = AnnotationBbox(imagebox, (i + 0.5, 0), frameon=False, box_alignment=(0.5, -0.2))
        ax.add_artist(ab)

    # Adjust X-axis
    ax.set_xticks(np.arange(len(prior_distribution)) + 0.5)
    ax.set_xticklabels([])
    ax.set_xlim(0, len(prior_distribution))
    ax.set_ylim(0, max(prior_distribution) * 1.2)
    ax.grid(axis='y', linestyle='--', alpha=0.7)

    # Show the plot
    plt.tight_layout()
    plt.show()