#!/usr/bin/env python3
import argparse
import matplotlib.pyplot as plt
import numpy as np
from sklearn import svm
from sklearn.utils import check_random_state
from typing import Tuple, Callable, List, Union
from tqdm import tqdm
from utils import read_input, save_data_to_buffer, load_data_from_buffer, load_MNIST, visualize_MNIST, plot_prior

parser = argparse.ArgumentParser(description="Process input and output file paths.")
parser.add_argument("input_file_path", type=str, help="Path to the input file")
parser.add_argument("output_file_path", type=str, nargs="?", default=None, help="Path to the output file")
# These arguments will be set appropriately by Brute, even if you change them.
parser.add_argument("--plot", action="store_true", help="Evaluation in Brute")
parser.add_argument("--brute", action="store_true", help="Evaluation in Brute")


def e_step(
    p_train_y_given_x: List[np.ndarray], p_train: np.ndarray, p_test: np.ndarray
) -> np.ndarray:
    """
    Perform the E-step: Estimate p_{test}(y|x) by reweighting the training predictions
    to account for the prior shift between training and test distributions.

    Args:
        p_train_y_given_x (List[np.ndarray]): List of arrays containing estimates of p_{tr}(y|x)
            for each sample. Each array has shape (num_classes,).
        p_train (np.ndarray): Known training priors p_train(y),
            an array of shape (num_classes,).
        p_test (np.ndarray): Current estimate of test priors p_test(y),
            an array of shape (num_classes,).

    Returns:
        np.ndarray: Array of shape (len(p_train_y_given_x), num_classes) containing updated
        estimates of p_{test}(y|x) for the test data.
    """

    # TODO: 1) Compute the reweighting vector p_{de}(y)/p_{tr}(y) used to compensate the prior shift between training and deployment (testing)
    tau = p_test / (p_train + 1e-14)

    p_test_y_given_x = []
    for i in range(len(p_train_y_given_x)):
        # TODO: 2) Recompute p_{de}(y|x) using the reweighting vector
        unnormalized_p_test_y_given_x = p_train_y_given_x[i] * tau
        # TODO: 3) Normalize the p_{de}(y|x) to sum to 1.0 for each sample
        normalized_p_test_y_given_x = unnormalized_p_test_y_given_x /(np.sum(unnormalized_p_test_y_given_x) + 1e-14)
        # TODO: 4) Save the prediction
        p_test_y_given_x.append(normalized_p_test_y_given_x)

    return np.array(p_test_y_given_x)


def m_step(p_test_y_given_x: Union[np.ndarray, List[np.ndarray]]) -> np.ndarray:
    """
    Perform the M-step: Update the test prior p_{test}(y) based on the current estimates
    of p_{test}(y|x).

    Args:
        p_test_y_given_x (Union[np.ndarray, List[np.ndarray]]):
            Array of shape (num_samples, num_classes) containing current estimates of
            p_{test}(y|x) for the test data.

    Returns:
        np.ndarray: Updated estimate of test priors p_{test}(y), an array of shape (num_classes,).
    """
    # TODO: 1) Compute the ML estimate of p_{test}(y)
    p_test = np.mean(p_test_y_given_x, axis=0)
    return p_test


def compute_test_priors(
    model: Callable[[np.ndarray], np.ndarray],
    X_test: Union[np.ndarray, List[List[float]]],
    p_train: Union[np.ndarray, List[float]]
) -> np.ndarray:
    """
    Estimate the test priors p_{test}(y) using the EM algorithm.

    Args:
        model (Callable[[np.ndarray], np.ndarray]): A callable model that outputs p_{train}(y|x)
            given input features x. The output is an array of shape (num_samples, num_classes).
        X_test (Union[np.ndarray, List[List[float]]]): Test set features, an array of shape
            (num_samples, num_features).
        p_train (Union[np.ndarray, List[float]]): Known training priors p_{train}(y),
            an array of shape (num_classes,).

    Returns:
        np.ndarray: Estimated test priors p_{test}(y), an array of shape (num_classes,).
    """
    num_classes = len(p_train)
    p_test = np.ones(num_classes) / num_classes  # Initialize p_{test}(y) uniformly
    p_train_y_given_x = model(X_test)  # Compute p_{train}(y|x) on

    epsilon = 1e-14  # Convergence threshold
    max_iter = 100  # Maximum number of iterations

    pbar = tqdm(range(max_iter), desc="EM Algorithm")
    for iteration in pbar:
        p_test_old = np.copy(p_test)  # Save the old p_{test}(y) for convergence check

        # TODO: 1) E step
        p_test_y_given_x = e_step(p_train_y_given_x, p_train, p_test)


        # TODO: 2) M step
        p_test = m_step(p_test_y_given_x)

        # Update the TQDM bar with current prior estimates
        pbar.set_postfix({"p_test": np.round(p_test, 2).tolist()})

        # Check for convergence
        if np.linalg.norm(p_test - p_test_old) < epsilon:
            break

    pbar.close()
    return p_test


def bayes_classifier_with_prior_shift(
    x: np.ndarray,
    model: Callable[[np.ndarray], np.ndarray],
    train_p_y: Union[np.ndarray, List[float]],
    test_p_y: Union[np.ndarray, List[float]],
    loss_matrix: np.ndarray
) -> Tuple[List[int], List[float]]:
    """
    Perform classification using a plug-in Bayes classifier, accounting for prior shift.

    Args:
        x (np.ndarray): A (num_samples, num_features) array representing the data points to classify.
        model (Callable[[np.ndarray], np.ndarray]): A callable that outputs p_{train}(y|x) 
            for input features x. The output should be an array of shape (num_classes,).
        train_p_y (Union[np.ndarray, List[float]]): A (num_classes,) array containing the 
            training prior probabilities for each class.
        test_p_y (Union[np.ndarray, List[float]]): A (num_classes,) array containing the 
            estimated test prior probabilities for each class.
        loss_matrix (np.ndarray): A (num_classes, num_classes) matrix where entry (i, j) 
            represents the loss incurred for predicting class j when the true class is i.

    Returns:
        Tuple[List[int], List[float]]:
            - List[int]: Predicted class labels for each input data point.
            - List[float]: Conditional risks corresponding to the predicted class for each input.
    """
    train_p_y = train_p_y.flatten()
    test_p_y = test_p_y.flatten()

    # Note:
    #   It would be more efficient to implement the logic below with matrix operations in numpy
    #   We present the template here with for loops so that it is easier to understand

    # 1) Compute posterior probabilities p_{tr}(y|x) for every sample
    p_tr_y_given_x = [pyx for pyx in model(x)]

    # TODO: 2) Compute the reweighting vector p_{de}(y)/p_{tr}(y) used to compensate the prior shift between training and deployment (testing)
    tau = test_p_y / (train_p_y + 1e-14)

    # TODO: 3) Recompute p_{de}(y|x) using the reweighting vector
    p_de_y_given_x_unnormalized = [pyx * tau for pyx in p_tr_y_given_x]

    # TODO: 4) Normalize the p_{de}(y|x) to sum to 1.0 for each sample
    p_de_y_given_x = []
    for unnormalized in p_de_y_given_x_unnormalized:
        denom = np.sum(unnormalized) + 1e-14
        p_de_y_given_x.append(unnormalized / denom)

    # TODO: 5) Compute conditional risks for each class for every sample
    risks_for_each_sample = []
    for pyx in p_de_y_given_x:
        risks_c = []
        for c in range(loss_matrix.shape[1]):
            risk_c = np.sum(pyx * loss_matrix[:, c])
            risks_c.append(risk_c)
        risks_for_each_sample.append(risks_c)

    # TODO: 6) Predict the class with the minimum risk for every sample
    predicted_classes = [np.argmin(risks) for risks in risks_for_each_sample]
    predicted_risks = [risks[predicted_class] for risks, predicted_class in zip(risks_for_each_sample, predicted_classes)]

    return predicted_classes, predicted_risks


def test_E_step(args):
    # Read the input data as a dictionary
    data = read_input(args.input_file_path)["e_step"]
    # Compute output of the expectation step
    student_output = {
        "e_step": e_step(data["p_train_y_given_x"], data["p_train"], data["p_test"])
    }

    # Evaluate on public instances
    if not args.brute:
        print("\nEM Algorithm - E Step:")
        reference_output = load_data_from_buffer(
            args.input_file_path.replace("instances", "solutions").replace(".json", "")
        )["e_step"]
        for name in reference_output.keys():
            are_identical = all(
                [
                    np.allclose(
                        student_output[name][i],
                        reference_output[name][i],
                        rtol=1e-05,
                        atol=1e-05,
                    )
                    for i in range(len(student_output[name]))
                ]
            )

            if are_identical:
                print(f"\t{name}: Test OK")
            else:
                print(f"\t{name}: Test Failed")

    return student_output


def test_M_step(args):
    # Read the input data as a dictionary
    data = read_input(args.input_file_path)["m_step"]
    # Compute output of the maximization step
    student_output = {"m_step": m_step(data["p_test_y_given_x"])}

    # Evaluate on public instances
    if not args.brute:
        print("\nEM Algorithm - M Step:")
        reference_output = load_data_from_buffer(
            args.input_file_path.replace("instances", "solutions").replace(".json", "")
        )["m_step"]

        for name in reference_output.keys():
            are_identical = all(
                [
                    np.allclose(
                        student_output[name][i],
                        reference_output[name][i],
                        rtol=1e-05,
                        atol=1e-05,
                    )
                    for i in range(len(student_output[name]))
                ]
            )

            if are_identical:
                print(f"\t{name}: Test OK")
            else:
                print(f"\t{name}: Test Failed")

    return student_output


def test_EM_algorithm(args):
    # Read the input data as a dictionary
    data = read_input(args.input_file_path)
    train_indexes = data["bayes_classifier"]["train_indexes"]
    test_indexes = data["bayes_classifier"]["test_indexes"]
    loss_matrix = data["bayes_classifier"]["loss_matrix"]

    # Load MNIST
    X, y = load_MNIST(brute=args.brute)
    # Separate it into training and test data
    # Note that for the test data, we would not be given the true labels y in practice
    # Here, we load the test labels in order to evaluate the performance of our model; however, we do not use the labels to estimate the test priors
    X_train, y_train, X_test, y_test = (
        X[train_indexes],
        y[train_indexes],
        X[test_indexes],
        y[test_indexes],
    )
    # Compute the training dataset prior
    labels, counts = np.unique(y_train, return_counts=True)
    true_train_prior = counts / sum(counts)
    # Make sure that each of the 10 classes is the training data
    assert len(counts) == 10
    # Train a classifier to estimate p_{tr}(y|x)
    # As we are using MNIST (the observations are images), ideally we would use a convolutional network to process it
    # Here, we treat each image as a flattened vector and train a Support-Vector-Machine classifier with RBF kernels instead
    np.random.seed(42)
    rng = check_random_state(42)
    clf = svm.SVC(gamma=0.001, probability=True)
    clf.fit(X_train, y_train)

    # Estimate p_{tr}(y|x)
    def predict_posterior(X):
        return clf.predict_proba(X)

    # Estimate test priors with the Expectation-Maximization Algorithm
    print("\nRunning EM ...")
    estimated_test_prior = compute_test_priors(
        predict_posterior, X_test, true_train_prior
    )
    student_output = {"estimated_test_prior": estimated_test_prior}

    # Evaluate on public instances
    if not args.brute:
        print("\nEM Algorithm - Estimated priors:")
        reference_output = load_data_from_buffer(
            args.input_file_path.replace("instances", "solutions").replace(".json", "")
        )["em_algorithm"]
        for name in reference_output.keys():
            are_identical = all(
                [
                    np.allclose(
                        student_output[name][i],
                        reference_output[name][i],
                        rtol=1e-05,
                        atol=1e-05,
                    )
                    for i in range(len(student_output[name]))
                ]
            )

            if are_identical:
                print(f"\t{name}: Test OK")
            else:
                print(f"\t{name}: Test Failed")

    return student_output


def test_bayes_classifier(args):
    # Read the input data as a dictionary
    data = read_input(args.input_file_path)["bayes_classifier"]

    # Load training and test priors. Here, we assume that the priors are known. In a different part of the homework, you will estimate the test priors with the EM algorithm
    true_train_prior = data["true_train_prior"]
    dummy_test_prior = data["dummy_test_prior"]
    loss_matrix = data["loss_matrix"]
    train_indexes = data["train_indexes"]
    test_indexes = data["test_indexes"]

    # Load MNIST
    X, y = load_MNIST(brute=args.brute)

    # Separate it into training and test data
    # Note that for the test data, we would not be given the true labels y in practice
    # Here, we load the test labels in order to evaluate the performance of our model; however, we do not use the labels to estimate the test priors
    X_train, y_train, X_test, y_test = (
        X[train_indexes],
        y[train_indexes],
        X[test_indexes],
        y[test_indexes],
    )

    # Compute the training dataset prior
    labels, counts = np.unique(y_train, return_counts=True)
    true_train_prior = counts / sum(counts)
    # Make sure that each of the 10 classes is the training data
    assert len(counts) == 10

    # Train a classifier to estimate p_{tr}(y|x)
    # As we are using MNIST (the observations are images), ideally we would use a convolutional network to process it
    # Here, we treat each image as a flattened vector and train a Support-Vector-Machine classifier with RBF kernels instead
    np.random.seed(42)
    rng = check_random_state(42)
    clf = svm.SVC(gamma=0.001, probability=True)
    clf.fit(X_train, y_train)

    # Callable to estimate p_{tr}(y|x); With scikit, we need to invoke 'predict_proba'
    def predict_posterior(X):
        return clf.predict_proba(X)

    # Compute compensated predictions and according risks
    compensated_predictions, risks_of_predictions = bayes_classifier_with_prior_shift(
        X_test, predict_posterior, true_train_prior, dummy_test_prior, loss_matrix
    )

    # To assess whether your implementation is correct, we compare the risks of the predictions instead of the predictions themselves
    # The class prediction (argmin) could be non-unique, however, the smallest risk (min) for each sample should be unique
    student_output = {"risks": risks_of_predictions}

    # Evaluate on public instances
    if not args.brute:
        print("\nBayes Classifier:")
        reference_output = load_data_from_buffer(
            args.input_file_path.replace("instances", "solutions").replace(".json", "")
        )["bayes_classifier"]

        for name in reference_output.keys():
            are_identical = all(
                [
                    np.allclose(
                        student_output[name][i],
                        reference_output[name][i],
                        rtol=1e-05,
                        atol=1e-05,
                    )
                    for i in range(len(student_output[name]))
                ]
            )

            if are_identical:
                print(f"\t{name} bayes_classifier: Test OK")
            else:
                print(f"\t{name} bayes_classifier: Test Failed")

    return student_output


def main(args):
    # Test E-Step
    e_step_output = test_E_step(args)
    # Test M-Step
    m_step_output = test_M_step(args)
    # Test EM algorithm
    em_algorithm_output = test_EM_algorithm(args)
    # Test Bayes classifier
    bayes_classifier_output = test_bayes_classifier(args)

    if args.brute:
        save_data_to_buffer(
            {
                "e_step": e_step_output,
                "m_step": m_step_output,
                "em_algorithm": em_algorithm_output,
                "bayes_classifier": bayes_classifier_output,
            },
            args.output_file_path,
        )

    if args.plot:
        # Illustrate the entire pipeline of:
        #   1) training the model,
        #   2) estimating deployment priors,
        #   3) predicting outputs for test data

        # Show the data we will be working with
        visualize_MNIST()
        data = read_input(args.input_file_path)
        train_indexes = data["bayes_classifier"]["train_indexes"]
        test_indexes = data["bayes_classifier"]["test_indexes"]
        loss_matrix = data["bayes_classifier"]["loss_matrix"]

        # Load MNIST
        X, y = load_MNIST(brute=args.brute)

        # Separate it into training and test data
        # Note that for the test data, we would not be given the true labels y in practice
        # Here, we load the test labels in order to evaluate the performance of our model; however, we do not use the labels to estimate the test priors
        X_train, y_train, X_test, y_test = (
            X[train_indexes],
            y[train_indexes],
            X[test_indexes],
            y[test_indexes],
        )

        # Compute the training dataset prior
        labels, counts = np.unique(y_train, return_counts=True)
        true_train_prior = counts / sum(counts)
        # Make sure that each of the 10 classes is the training data
        assert len(counts) == 10

        # Train a classifier to estimate p_{tr}(y|x)
        # As we are using MNIST (the observations are images), ideally we would use a convolutional network to process it
        # Here, we treat each image as a flattened vector and train a Support-Vector-Machine classifier with RBF kernels instead
        print("\nTraining classifier ... This may take a minute")
        np.random.seed(42)
        rng = check_random_state(42)
        clf = svm.SVC(gamma=0.001, probability=True)
        clf.fit(X_train, y_train)

        # Estimate p_{tr}(y|x)
        def predict_posterior(X):
            return clf.predict_proba(X)

        # Estimate test priors with the Expectation-Maximization Algorithm
        print("\nRunning EM ...")
        estimated_test_prior = compute_test_priors(
            predict_posterior, X_test, true_train_prior
        )

        # Visualize the training prior and the estimated test prior
        plot_prior(true_train_prior, title="Training Priors p(y)")
        plot_prior(estimated_test_prior, title="Estimated Test Priors p(y)")

        # Evaluate whether the prior compensation improved our loss
        compensated_predictions, _ = bayes_classifier_with_prior_shift(
            X_test,
            predict_posterior,
            true_train_prior,
            estimated_test_prior,
            loss_matrix,
        )
        uncompensated_predictions, _ = bayes_classifier_with_prior_shift(
            X_test, predict_posterior, true_train_prior, true_train_prior, loss_matrix
        )
        average_compensated_loss = np.mean(
            [
                loss_matrix[y_, p_]
                for x_, y_, p_ in zip(X_test, y_test, compensated_predictions)
            ]
        )
        average_uncompensated_loss = np.mean(
            [
                loss_matrix[y_, p_]
                for x_, y_, p_ in zip(X_test, y_test, uncompensated_predictions)
            ]
        )
        print("Without prior compensation; Loss:", np.round(average_uncompensated_loss, 2))
        print("With prior compensation; Loss:", np.round(average_compensated_loss, 2))
        print("Improvement: ", np.round(average_uncompensated_loss - average_compensated_loss, 2))


if __name__ == "__main__":
    args = parser.parse_args()
    main(args)
